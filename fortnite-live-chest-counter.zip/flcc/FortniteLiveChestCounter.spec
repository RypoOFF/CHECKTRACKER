# PyInstaller spec — one-file, windowed, portable .exe
# Build:  pyinstaller FortniteLiveChestCounter.spec --noconfirm --clean
import sys
from pathlib import Path

root = Path(SPECPATH)
is_win = sys.platform == "win32"

# Qt modules we never use: excluding them keeps the .exe much smaller.
EXCLUDES = [
    "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets", "PySide6.QtWebEngineQuick",
    "PySide6.QtQml", "PySide6.QtQuick", "PySide6.QtQuickWidgets", "PySide6.Qt3DCore",
    "PySide6.QtMultimedia", "PySide6.QtCharts", "PySide6.QtDataVisualization", "PySide6.QtSql",
    "PySide6.QtNetwork", "PySide6.QtBluetooth", "PySide6.QtPdf", "PySide6.QtSvg",
    "tkinter", "matplotlib", "scipy", "pandas", "IPython", "pytest",
]

a = Analysis(
    ["run.py"],
    pathex=[str(root / "src")],
    datas=[(str(root / "assets" / "icon.ico"), "assets"), (str(root / "assets" / "icon.png"), "assets")],
    hiddenimports=["chestcounter.app", "mss", "psutil"] + (["mss.windows"] if is_win else []),
    excludes=EXCLUDES,
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="FortniteLiveChestCounter",
    icon=str(root / "assets" / "icon.ico"),
    console=False,          # GUI app, no console window
    upx=False,              # UPX triggers more antivirus false positives
    runtime_tmpdir=None,
)
