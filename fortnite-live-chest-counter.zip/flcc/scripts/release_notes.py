"""Print the CHANGELOG.md section for a tag (e.g. v1.2.0) -> used as the GitHub Release body."""
import re
import sys
from pathlib import Path

tag = sys.argv[1].lstrip("v")
text = (Path(__file__).resolve().parents[1] / "CHANGELOG.md").read_text(encoding="utf-8")
m = re.search(rf"^## \[?{re.escape(tag)}\]?.*?$\n(.*?)(?=^## |\Z)", text, re.S | re.M)
if not m or not m.group(1).strip():
    sys.exit(f"No CHANGELOG.md section found for version {tag}. Add '## [{tag}] - YYYY-MM-DD' first.")
print(m.group(1).strip())
