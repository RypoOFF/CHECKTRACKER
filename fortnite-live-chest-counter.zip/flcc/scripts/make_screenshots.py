"""Render README screenshots from a *synthetic demo* database (clearly labelled as demo).
Usage: python scripts/make_screenshots.py docs/screenshots
Needs a Qt platform: on a headless box run with QT_QPA_PLATFORM=offscreen."""
from __future__ import annotations

import os
import random
import sys
import tempfile
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
tmp = tempfile.mkdtemp(prefix="flcc-demo-")
os.environ["FLCC_DATA_DIR"] = tmp
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from PySide6.QtWidgets import QApplication  # noqa: E402

from chestcounter.config import AppConfig  # noqa: E402
from chestcounter.controller import Controller  # noqa: E402
from chestcounter.db import Database  # noqa: E402
from chestcounter.detection.engine import EngineStatus  # noqa: E402
from chestcounter.ui.main_window import MainWindow  # noqa: E402


def main(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    rnd = random.Random(7)
    app = QApplication([])
    cfg = AppConfig()
    ctl = Controller(cfg, Database(Path(tmp) / "demo.sqlite3"), start_engine=False)
    sm = ctl.sessions
    now = time.time()
    # DEMO DATA: past games
    for g in range(9):
        t0 = now - (9 - g) * 86400 - 3000
        sm.clock = lambda t0=t0: t0
        sm.start("auto", t0)
        t = t0
        for _ in range(rnd.randint(8, 24)):
            t += rnd.uniform(40, 130); sm.clock = lambda t=t: t
            sm.cfg.cooldown_s = 0
            sm.add_detection(rnd.choice(["normal"] * 5 + ["rare"]), rnd.uniform(0.7, 0.98), t, source="demo")
        sm.clock = lambda t=t: t + 120
        sm.end("inactivity")
    # DEMO DATA: current game
    sm.clock = time.time
    start = now - 14 * 60
    sm.start("auto", start)
    t = start
    for _ in range(11):
        t += rnd.uniform(45, 95); sm.add_detection(rnd.choice(["normal"] * 4 + ["rare"]), rnd.uniform(0.7, 0.98), t, source="demo")
    win = MainWindow(ctl); win.resize(1180, 780); win.show()
    st = EngineStatus(game_running=True, ready=True, fsm_state="armed", prompt_score=0.83, opened_score=0.0,
                      threshold=cfg.detection.match_threshold, last_confidence=0.78, last_decision="counted", fps=8.0, frame_ms=2.7,
                      log=["14:21:07 COUNTED         conf=0.78 kind=normal (no opened evidence)",
                           "14:20:12 LOW_CONFIDENCE  conf=0.34 kind=normal (no interact key press -> likely walked away)"][::-1])
    ctl.last_status = st; ctl.status_changed.emit(st)
    win.overlay.show(); win.overlay.move(900, 40)
    for i, name in enumerate(("dashboard", "live", "history", "settings")):
        win.go(i)
        if i == 2:
            win.pages[2][1].table.selectRow(0)
        app.processEvents(); app.processEvents()
        win.grab().save(str(out / f"{name}.png"))
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPixmap
    ov = win.overlay
    pix = QPixmap(ov.size()); pix.fill(Qt.transparent)
    ov.render(pix)                                             # translucent overlay only
    bg = QPixmap(ov.width() + 80, ov.height() + 80)            # fake dark "game" backdrop (illustration only)
    p = QPainter(bg); g = QLinearGradient(0, 0, bg.width(), bg.height())
    g.setColorAt(0, QColor("#2b4a6b")); g.setColorAt(1, QColor("#1a2a1f")); p.fillRect(bg.rect(), g)
    p.drawPixmap(40, 40, pix); p.end(); bg.save(str(out / "overlay.png"))
    ctl.shutdown() if False else None
    print("saved to", out)


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else "docs/screenshots"))
