"""Generate assets/icon.ico (+ icon.png) — a violet chest on an anthracite tile."""
from pathlib import Path
from PIL import Image, ImageDraw

out = Path(__file__).resolve().parents[1] / "assets"
out.mkdir(exist_ok=True)
S = 512
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
d.rounded_rectangle((16, 16, S - 16, S - 16), 96, fill=(22, 24, 31, 255), outline=(42, 46, 58, 255), width=6)
violet, dark, gold = (139, 92, 246, 255), (91, 58, 180, 255), (251, 191, 36, 255)
d.rounded_rectangle((96, 232, 416, 396), 22, fill=violet)                      # body
d.pieslice((96, 120, 416, 344), 180, 360, fill=dark)                            # lid
d.rectangle((96, 232, 416, 252), fill=(70, 44, 150, 255))                       # seam
d.rectangle((236, 232, 276, 396), fill=(70, 44, 150, 255))                      # strap
d.rounded_rectangle((226, 262, 286, 322), 10, fill=gold)                        # lock
d.ellipse((248, 282, 264, 298), fill=(22, 24, 31, 255))
img.save(out / "icon.png")
img.save(out / "icon.ico", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
print("icons written to", out)
