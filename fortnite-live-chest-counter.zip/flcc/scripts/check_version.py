"""Fail if the git tag does not match chestcounter.__version__ (prevents mislabelled releases)."""
import re
import sys
from pathlib import Path

tag = sys.argv[1].lstrip("v")
src = (Path(__file__).resolve().parents[1] / "src" / "chestcounter" / "__init__.py").read_text()
ver = re.search(r'__version__\s*=\s*"([^"]+)"', src).group(1)
if ver != tag:
    sys.exit(f"Tag v{tag} != __version__ {ver}. Bump src/chestcounter/__init__.py before tagging.")
print("version OK:", ver)
