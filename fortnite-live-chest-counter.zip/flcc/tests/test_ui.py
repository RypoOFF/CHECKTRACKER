import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import pytest
pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication

from chestcounter.config import AppConfig
from chestcounter.controller import Controller
from chestcounter.db import Database
from chestcounter.ui.main_window import MainWindow


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def win(app, tmp_path, monkeypatch):
    monkeypatch.setenv("FLCC_DATA_DIR", str(tmp_path))
    from chestcounter import paths
    cfg = AppConfig()
    ctl = Controller(cfg, Database(tmp_path / "ui.sqlite3"), start_engine=False)
    w = MainWindow(ctl)
    w.show()
    yield w
    w.overlay.close(); w.close(); ctl.db.close()


def test_pages_render_and_counter_updates(win, app):
    ctl = win.ctl
    for i in range(4):
        win.go(i); app.processEvents()
    ctl.sessions.cfg.cooldown_s = 0
    assert ctl.sessions.add_detection("normal", 0.9).counted
    ctl.sessions.adjust(+1)
    app.processEvents()
    dash = win.pages[0][1]
    dash.refresh()
    assert dash.counter._value == 2
    assert win.overlay._values["chests"] == "2" or (win.overlay.refresh() or win.overlay._values["chests"] == "2")
    ctl.sessions.adjust(-1); dash.refresh()
    assert dash.counter._value == 1


def test_buttons_work(win, app):
    dash = win.pages[0][1]
    dash.b_add.click(); dash.b_add.click(); dash.b_rem.click()
    assert win.ctl.sessions.total == 1
    dash.b_session.click()                       # end session
    assert not win.ctl.sessions.active
    hist = win.pages[2][1]; hist.refresh()
    assert hist.table.rowCount() == 1
    hist.table.selectRow(0); hist.show_selected()
    assert hist.c_total.value.text() == "1"


def test_settings_save_roundtrip(win, app, tmp_path):
    s = win.pages[3][1]
    s.f_fps.setValue(5); s.f_thr.setValue(0.8); s.o_fs.setValue(1.5)
    s.o_stats["avg_interval"].setChecked(True)
    s.save()
    d, o = win.ctl.cfg.detection, win.ctl.cfg.overlay
    assert d.fps == 5 and d.match_threshold == pytest.approx(0.8) and o.font_scale == 1.5
    assert "avg_interval" in o.stats
    assert (tmp_path / "config.json").exists()


def test_overlay_flags_and_geometry(win):
    ov = win.overlay
    from PySide6.QtCore import Qt
    assert ov.windowFlags() & Qt.WindowStaysOnTopHint
    assert ov.testAttribute(Qt.WA_TranslucentBackground)
    ov.cfg.click_through = True; ov.apply_config()
    assert ov.windowFlags() & Qt.WindowTransparentForInput
    ov.cfg.click_through = False; ov.apply_config()
    ov.cfg.x, ov.cfg.y = 99999, 99999            # saved on a monitor that no longer exists
    ov._place()
    assert ov.geometry().x() < 5000


def test_calibration_saves_template_and_roi(win, app):
    import numpy as np
    from PySide6.QtCore import QRect
    from chestcounter.ui.calibration import CalibrationDialog
    img = np.random.default_rng(3).integers(0, 255, (720, 1280, 3), dtype=np.uint8)
    dlg = CalibrationDialog(img, win.ctl); dlg.resize(1100, 720); dlg.show(); app.processEvents()
    dlg.canvas.sel = QRect(dlg.canvas._origin().x() + 100, dlg.canvas._origin().y() + 100, 200, 80)
    dlg.mode.setCurrentIndex(1); dlg.save()
    assert len(win.ctl.library.by_role("prompt")) == 1
    dlg.mode.setCurrentIndex(0); dlg.save()
    assert 0 < win.ctl.cfg.detection.roi[2] < 1
