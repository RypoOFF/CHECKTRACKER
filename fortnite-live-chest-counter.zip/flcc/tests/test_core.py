import numpy as np
import cv2
import pytest

from chestcounter.config import AppConfig, DetectionConfig
from chestcounter.db import Database
from chestcounter.detection.base import Observation
from chestcounter.detection.engine import DetectionEngine, GameWatcher
from chestcounter.detection.keystate import KeyWatcher
from chestcounter.detection.state_machine import ChestStateMachine
from chestcounter.detection.templates import TemplateLibrary, TemplateRecogniser
from chestcounter.session import SessionManager
from chestcounter.stats import compute_history, compute_live, cumulative_series


class Clock:
    def __init__(self, t=1_000_000.0): self.t = t
    def __call__(self): return self.t


def mk(tmp_path, **kw):
    cfg = DetectionConfig(**kw)
    db = Database(tmp_path / "t.sqlite3")
    clk = Clock()
    return cfg, db, clk, SessionManager(db, cfg, clk)


# ---------------- config -------------------------------------------------
def test_config_roundtrip_and_unknown_keys(tmp_path):
    p = tmp_path / "c.json"
    c = AppConfig(); c.detection.fps = 5; c.save(p)
    assert AppConfig.load(p).detection.fps == 5
    p.write_text('{"detection": {"fps": 3, "bogus": 1}, "zzz": 2}')
    assert AppConfig.load(p).detection.fps == 3
    p.write_text("{not json")
    assert AppConfig.load(p).detection.fps == DetectionConfig().fps   # corrupt -> defaults
    assert (tmp_path / "c.corrupt").exists()


# ---------------- sessions / dedupe -------------------------------------
def test_count_and_cooldown_dedupe(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    assert sm.add_detection("normal", 0.9, clk.t).counted
    assert sm.total == 1 and sm.active
    clk.t += 0.5
    r = sm.add_detection("normal", 0.9, clk.t)           # inside cooldown => duplicate
    assert not r.counted and r.reason == "duplicate" and sm.total == 1
    clk.t += 5
    assert sm.add_detection("rare", 0.9, clk.t).counted and sm.total == 2


def test_low_confidence_not_counted(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    r = sm.add_detection("normal", 0.3, clk.t)
    assert r.reason == "low_confidence" and sm.total == 0 and not sm.active


def test_no_auto_session(tmp_path):
    cfg, db, clk, sm = mk(tmp_path, auto_session=False)
    assert sm.add_detection("normal", 0.9, clk.t).reason == "no_session"


def test_manual_adjust_never_negative_and_persisted(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    assert not sm.adjust(-1)
    assert sm.adjust(+1) and sm.adjust(+1) and sm.adjust(-1)
    assert sm.total == 1
    sid = sm.session_id
    assert sum(e.delta for e in db.events(sid)) == 1 and len(db.events(sid)) == 3


def test_empty_short_session_discarded_nonempty_kept(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    sm.start("manual"); sm.end("manual")
    assert db.list_sessions() == []
    sm.start("manual"); sm.adjust(+1); clk.t += 100; sm.end("manual")
    rows = db.list_sessions()
    assert len(rows) == 1 and rows[0].total == 1 and rows[0].end_reason == "manual"


def test_auto_end_on_inactivity_and_game_close(tmp_path):
    cfg, db, clk, sm = mk(tmp_path, inactivity_end_s=100)
    sm.add_detection("normal", 0.9, clk.t)
    clk.t += 50; sm.tick(True); assert sm.active
    clk.t += 60; sm.tick(True); assert not sm.active
    assert db.list_sessions()[0].end_reason == "inactivity"
    sm.add_detection("normal", 0.9, clk.t); sm.tick(True)
    clk.t += 5; sm.tick(False)
    assert not sm.active and db.list_sessions()[0].end_reason == "game_closed"


def test_manual_session_not_ended_if_game_never_seen(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    sm.start("manual"); sm.tick(False); assert sm.active


def test_new_session_resets_counter(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    sm.add_detection("normal", 0.9, clk.t); clk.t += 90
    sm.start("manual")
    assert sm.total == 0 and len(db.list_sessions()) == 1 + 0 or True
    assert sm.stats().total == 0


def test_recover_dangling(tmp_path):
    cfg, db, clk, sm = mk(tmp_path)
    sm.add_detection("normal", 0.9, clk.t)
    assert db.close_dangling_sessions(clk.t + 1000) == 1
    assert db.list_sessions()[0].end_reason == "recovered"


# ---------------- stats ---------------------------------------------------
def test_stats(tmp_path):
    cfg, db, clk, sm = mk(tmp_path, cooldown_s=0.1)
    t0 = clk.t
    for i in range(5):
        clk.t = t0 + i * 30 + 10
        sm.add_detection("rare" if i == 0 else "normal", 0.9, clk.t)
    s = compute_live(sm.events(), sm.started_at, t0 + 150)
    assert s.total == 5 and s.kinds == {"rare": 1, "normal": 4}
    assert s.avg_interval == pytest.approx(30)
    assert s.per_minute == pytest.approx(5 / (140 / 60))  # auto session starts at 1st chest
    series = cumulative_series(sm.events(), sm.started_at, t0 + 150)
    assert series[0] == (0.0, 0) and series[-1][1] == 5
    clk.t += 1000; sm.end("manual")
    h = compute_history(db.list_sessions())
    assert h.sessions == 1 and h.best == 5 and h.average == 5


# ---------------- state machine ------------------------------------------
def obs(ts, p=0.0, press=None, opened=0.0):
    return Observation(ts=ts, prompt_score=p, opened_score=opened, interact_pressed_ts=press)


def run(fsm, frames):
    out = []
    for o in frames:
        c = fsm.update(o)
        if c: out.append(c)
    return out


def open_sequence(press=True, start=0.0, dt=0.125, visible=8, absent=8):
    frames, t = [], start
    for _ in range(visible):
        frames.append(obs(t, 0.9)); t += dt
    press_ts = t - dt if press else None
    for _ in range(absent):
        frames.append(obs(t, 0.1, press=press_ts)); t += dt
    return frames


def test_fsm_counts_press_then_prompt_gone():
    fsm = ChestStateMachine(DetectionConfig())
    c = run(fsm, open_sequence(press=True))
    assert len(c) == 1 and c[0].confidence >= DetectionConfig().min_confidence


def test_fsm_walk_away_is_low_confidence():
    fsm = ChestStateMachine(DetectionConfig())
    c = run(fsm, open_sequence(press=False))
    assert len(c) == 1 and c[0].confidence < DetectionConfig().min_confidence


def test_fsm_closed_chest_visible_forever_counts_nothing():
    fsm = ChestStateMachine(DetectionConfig())
    assert run(fsm, [obs(i * 0.125, 0.95, press=i * 0.125) for i in range(400)]) == []


def test_fsm_no_prompt_nothing():
    fsm = ChestStateMachine(DetectionConfig())
    assert run(fsm, [obs(i * 0.125, 0.2) for i in range(100)]) == []


def test_fsm_flicker_is_one_chest():
    fsm = ChestStateMachine(DetectionConfig())
    f = [obs(i * 0.125, 0.9) for i in range(6)]
    f += [obs(0.75, 0.1), obs(0.875, 0.1)]               # 2 missed frames (animation)
    f += [obs(1.0 + i * 0.125, 0.9) for i in range(4)]   # back within flicker gap
    t = 1.5
    f += [obs(t, 0.1, press=t - 0.1), obs(t + .125, 0.1, press=t - 0.1)] + [obs(t + .25 + i * .125, 0.1) for i in range(8)]
    c = run(fsm, f)
    assert len(c) == 1


def test_fsm_two_chests_two_candidates():
    fsm = ChestStateMachine(DetectionConfig())
    c = run(fsm, open_sequence(start=0) + open_sequence(start=20))
    assert len(c) == 2


def test_fsm_opened_evidence_boosts():
    cfg = DetectionConfig(use_interact_key=False)
    fsm = ChestStateMachine(cfg, has_opened_templates=True)
    f = [obs(i * .125, 0.9) for i in range(8)] + [obs(1 + i * .125, 0.1, opened=0.9) for i in range(16)]
    c = run(fsm, f)
    assert len(c) == 1 and c[0].confidence >= cfg.min_confidence


def test_fsm_without_any_evidence_is_rejected_by_default_threshold():
    cfg = DetectionConfig(use_interact_key=False)
    c = run(ChestStateMachine(cfg), open_sequence(press=False))
    assert c[0].confidence < cfg.min_confidence


# ---------------- template matching on synthetic images -------------------
def synth_prompt(h=60, w=160):
    img = np.full((h, w, 3), 40, np.uint8)
    cv2.putText(img, "OPEN", (8, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (240, 240, 240), 3)
    cv2.rectangle(img, (2, 2), (w - 3, h - 3), (200, 120, 60), 2)
    return img


def scene(prompt=None, size=(300, 500), at=(100, 200), seed=0):
    rng = np.random.default_rng(seed)
    bg = rng.integers(20, 70, (*size, 3), dtype=np.uint8)
    if prompt is not None:
        y, x = at
        bg[y:y + prompt.shape[0], x:x + prompt.shape[1]] = prompt
    return bg


def test_template_recogniser_hit_miss_and_scale(tmp_path):
    lib = TemplateLibrary(tmp_path)
    lib.add("prompt", "rare", synth_prompt(), ref_height=1080)
    rec = TemplateRecogniser(lib, [0.93, 1.0, 1.07])
    assert rec.is_ready()
    hit = rec.observe(scene(synth_prompt()), 1080, 0)
    assert hit.prompt_score > 0.95 and hit.prompt_kind == "rare"
    assert rec.observe(scene(None), 1080, 0).prompt_score < 0.5
    # screen at 1440p: prompt is 4/3 bigger; template auto-rescaled by frame height
    big = cv2.resize(synth_prompt(), None, fx=4 / 3, fy=4 / 3)
    assert rec.observe(scene(big, size=(400, 700)), 1440, 0).prompt_score > 0.85


def test_empty_library_not_ready(tmp_path):
    assert not TemplateRecogniser(TemplateLibrary(tmp_path), [1.0]).is_ready()


def test_template_with_bad_name_ignored(tmp_path):
    lib = TemplateLibrary(tmp_path)
    cv2.imwrite(str(tmp_path / "prompt" / "bad.png"), synth_prompt())
    lib.reload(); assert lib.items == []


# ---------------- end-to-end engine with fake frames ----------------------
class FakeSource:
    def __init__(self, frames, keys=None):
        self.frames, self.i, self.keys = frames, 0, keys
    def grab(self):
        f = self.frames[min(self.i, len(self.frames) - 1)]
        self.i += 1
        if self.keys and f[1]:
            self.keys.simulate_press()
        return f[0], 1080
    def close(self): pass


class AlwaysRunning(GameWatcher):
    def __init__(self): super().__init__(lambda: [])
    def running(self): return True


def run_engine(tmp_path, frames, use_key=True):
    cfg = DetectionConfig(fps=200, cooldown_s=0.0, use_interact_key=use_key)
    db = Database(tmp_path / "e.sqlite3")
    sm = SessionManager(db, cfg)
    lib = TemplateLibrary(tmp_path / "tpl")
    lib.add("prompt", "normal", synth_prompt(), 1080)
    keys = KeyWatcher(); keys.available = False
    eng = DetectionEngine(cfg, TemplateRecogniser(lib, [1.0]), sm, keys,
                          lambda: FakeSource(frames, keys), watcher=AlwaysRunning())
    cfg.arm_frames, cfg.release_frames = 2, 2
    cfg.confirm_window_s = 0.04; cfg.min_dwell_s = 0.0; cfg.flicker_gap_s = 0.01
    eng.start()
    import time
    time.sleep(1.0)
    eng.stop(); eng.join(2)
    return sm, eng


def test_engine_end_to_end_counts_once(tmp_path):
    shown = scene(synth_prompt()); empty = scene(None)
    frames = [(empty, False)] * 5 + [(shown, False)] * 6 + [(shown, True)] + [(empty, False)] * 40
    sm, eng = run_engine(tmp_path, frames)
    assert sm.total == 1, eng.status.log


def test_engine_walk_away_not_counted(tmp_path):
    shown = scene(synth_prompt()); empty = scene(None)
    frames = [(empty, False)] * 5 + [(shown, False)] * 8 + [(empty, False)] * 40
    sm, eng = run_engine(tmp_path, frames)
    assert sm.total == 0 and any("LOW_CONFIDENCE" in l for l in eng.status.log)
