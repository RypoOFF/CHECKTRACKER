# Architecture, analysis & plan

## 1. Reference project (LED-N/Fortnite-ChestCounter v1.4.0)
Counts chests **from Fortnite replay files** after each match, with an overlay and a report; no game-memory access; distributed as a `ChestCounter.exe` built by GitHub Actions. Consequence: it cannot update during a match. This project keeps the same principles (no memory access, local data, exe via Actions) but changes the data source.

## 2. Live-detection options
| Option | Verdict |
|---|---|
| Read/modify game memory, inject DLLs | **Rejected** (cheating; ban risk) |
| Public/official live event API | None exists for in-match chest events |
| Replay files | Post-match only (the replay is finalised at match end). Good as verification — *not implemented yet* |
| Screen capture + template matching (OpenCV) | **Chosen**: light, explainable, user-calibrated |
| OCR of the interact prompt | Possible plug-in; heavier, language-dependent |
| YOLO/CNN chest detector | Possible plug-in; needs a labelled dataset I can't produce here; chests are seen from many angles/lighting |
| Interact-key state (`GetAsyncKeyState`) | **Used as corroborating evidence** (hybrid) |

## 3. Limits
Visual detection alone cannot distinguish *opening* a chest from *walking away* (the prompt vanishes either way) — hence the hybrid evidence model. HUD changes need recalibration. Per-player counts and match boundaries are not visible on screen. Exclusive fullscreen can block capture.

## 4. Modules
```
src/chestcounter/
  config.py  paths.py  logging_setup.py   settings, portable/APPDATA paths, logs
  db.py      stats.py                      SQLite (sessions, events), pure stats
  session.py                               SINGLE place the counter changes: dedupe, confidence gate, lifecycle
  capture.py                               mss region capture
  detection/
    base.py            Recogniser protocol + Observation    ← add YOLO/OCR recognisers here
    templates.py       template library + multi-scale matcher
    state_machine.py   IDLE→ARMED→PENDING→decision (pure, unit-tested)
    keystate.py        interact-key watcher
    engine.py          worker thread: game watcher → capture → recognise → FSM → SessionManager
  hotkeys.py controller.py
  ui/  main_window, pages, overlay, calibration, widgets, theme
```
Counter changes are rows in `events` (`delta` ±1, `kind`, `confidence`, `source`: vision / manual / future replay), so corrections are auditable and a replay verifier can later reconcile against them.

## 5. Dedupe
1. Count only a prompt *transition*, never "chest visible".
2. Re-arm only after the prompt has been absent (`release_frames`), flicker < `flicker_gap_s` merges.
3. Global `cooldown_s` lockout in `SessionManager` for every source.

## 6. Roadmap
Replay verification · optional OCR/YOLO recognisers · bundled community template packs · code signing.
