"""SQLite persistence. Every counter change is an auditable row in ``events``
(delta +1 for detections / manual add, -1 for manual correction)."""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS sessions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at REAL NOT NULL,
  ended_at REAL,
  start_source TEXT NOT NULL DEFAULT 'manual',
  end_reason TEXT,
  note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  ts REAL NOT NULL,
  offset_s REAL NOT NULL,
  delta INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT 'normal',
  confidence REAL NOT NULL DEFAULT 1.0,
  source TEXT NOT NULL DEFAULT 'vision',
  details TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id, ts);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version','1');
"""


@dataclass
class SessionRow:
    id: int
    started_at: float
    ended_at: float | None
    start_source: str
    end_reason: str | None
    note: str
    total: int = 0

    @property
    def duration(self) -> float | None:
        return None if self.ended_at is None else max(0.0, self.ended_at - self.started_at)


@dataclass
class EventRow:
    id: int
    session_id: int
    ts: float
    offset_s: float
    delta: int
    kind: str
    confidence: float
    source: str
    details: str


class Database:
    def __init__(self, path: Path | str):
        self._lock = threading.RLock()
        self._con = sqlite3.connect(str(path), check_same_thread=False)
        self._con.row_factory = sqlite3.Row
        self._con.execute("PRAGMA foreign_keys=ON")
        with self._lock:
            self._con.executescript(SCHEMA)
            self._con.commit()

    def close(self) -> None:
        with self._lock:
            self._con.close()

    # -- sessions -----------------------------------------------------------
    def create_session(self, started_at: float, source: str) -> int:
        with self._lock:
            cur = self._con.execute(
                "INSERT INTO sessions(started_at,start_source) VALUES(?,?)", (started_at, source))
            self._con.commit()
            return int(cur.lastrowid)

    def end_session(self, sid: int, ended_at: float, reason: str) -> None:
        with self._lock:
            self._con.execute("UPDATE sessions SET ended_at=?, end_reason=? WHERE id=?",
                              (ended_at, reason, sid))
            self._con.commit()

    def delete_session(self, sid: int) -> None:
        with self._lock:
            self._con.execute("DELETE FROM sessions WHERE id=?", (sid,))
            self._con.commit()

    def set_note(self, sid: int, note: str) -> None:
        with self._lock:
            self._con.execute("UPDATE sessions SET note=? WHERE id=?", (note, sid))
            self._con.commit()

    def close_dangling_sessions(self, now: float) -> int:
        """After a crash/power loss, close sessions that never got an end time
        (ended at their last event, or their start)."""
        with self._lock:
            rows = self._con.execute("SELECT id, started_at FROM sessions WHERE ended_at IS NULL").fetchall()
            for r in rows:
                last = self._con.execute("SELECT MAX(ts) m FROM events WHERE session_id=?",
                                         (r["id"],)).fetchone()["m"]
                self._con.execute("UPDATE sessions SET ended_at=?, end_reason='recovered' WHERE id=?",
                                  (last or r["started_at"], r["id"]))
            self._con.commit()
            return len(rows)

    def list_sessions(self, limit: int | None = None) -> list[SessionRow]:
        q = ("SELECT s.*, COALESCE((SELECT SUM(delta) FROM events e WHERE e.session_id=s.id),0) AS total "
             "FROM sessions s ORDER BY s.started_at DESC")
        if limit:
            q += f" LIMIT {int(limit)}"
        with self._lock:
            return [SessionRow(r["id"], r["started_at"], r["ended_at"], r["start_source"],
                               r["end_reason"], r["note"], int(r["total"]))
                    for r in self._con.execute(q).fetchall()]

    def get_session(self, sid: int) -> SessionRow | None:
        with self._lock:
            r = self._con.execute(
                "SELECT s.*, COALESCE((SELECT SUM(delta) FROM events e WHERE e.session_id=s.id),0) AS total "
                "FROM sessions s WHERE s.id=?", (sid,)).fetchone()
        if not r:
            return None
        return SessionRow(r["id"], r["started_at"], r["ended_at"], r["start_source"],
                          r["end_reason"], r["note"], int(r["total"]))

    # -- events -------------------------------------------------------------
    def add_event(self, sid: int, ts: float, offset_s: float, delta: int, kind: str,
                  confidence: float, source: str, details: str = "") -> int:
        with self._lock:
            cur = self._con.execute(
                "INSERT INTO events(session_id,ts,offset_s,delta,kind,confidence,source,details) "
                "VALUES(?,?,?,?,?,?,?,?)", (sid, ts, offset_s, delta, kind, confidence, source, details))
            self._con.commit()
            return int(cur.lastrowid)

    def delete_event(self, eid: int) -> None:
        with self._lock:
            self._con.execute("DELETE FROM events WHERE id=?", (eid,))
            self._con.commit()

    def events(self, sid: int) -> list[EventRow]:
        with self._lock:
            rows = self._con.execute("SELECT * FROM events WHERE session_id=? ORDER BY ts, id", (sid,)).fetchall()
        return [EventRow(r["id"], r["session_id"], r["ts"], r["offset_s"], r["delta"], r["kind"],
                         r["confidence"], r["source"], r["details"]) for r in rows]

    def export_rows(self) -> Iterable[tuple]:
        with self._lock:
            return self._con.execute(
                "SELECT s.id, s.started_at, s.ended_at, COALESCE(SUM(e.delta),0) "
                "FROM sessions s LEFT JOIN events e ON e.session_id=s.id GROUP BY s.id ORDER BY s.id").fetchall()
