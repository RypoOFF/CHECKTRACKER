"""Screen capture through DXGI/GDI via ``mss`` (works on borderless/windowed
fullscreen; protected exclusive-fullscreen surfaces may come back black)."""
from __future__ import annotations

import logging
from typing import Protocol

import numpy as np

log = logging.getLogger("chestcounter.detection.capture")


def _new_mss():
    import mss  # imported lazily: keeps unit tests/headless imports light
    return getattr(mss, "MSS", None) and mss.MSS() or mss.mss()


class FrameSource(Protocol):
    def grab(self) -> tuple[np.ndarray, int]:
        """Return (ROI as BGR ndarray, full monitor height in px)."""
    def close(self) -> None: ...


class MssSource:
    def __init__(self, monitor: int, roi: list[float]):
        self._mss = _new_mss()
        mons = self._mss.monitors
        if not (1 <= monitor < len(mons)):
            log.warning("Monitor %s not found, using primary", monitor)
            monitor = 1
        m = mons[monitor]
        x, y, w, h = roi
        self.height = int(m["height"])
        self.box = {"left": int(m["left"] + x * m["width"]), "top": int(m["top"] + y * m["height"]),
                    "width": max(16, int(w * m["width"])), "height": max(16, int(h * m["height"]))}

    def grab(self) -> tuple[np.ndarray, int]:
        shot = self._mss.grab(self.box)
        arr = np.asarray(shot)[:, :, :3]  # BGRA -> BGR (view; cv2 needs contiguous copy later)
        return np.ascontiguousarray(arr), self.height

    def close(self) -> None:
        try:
            self._mss.close()
        except Exception:
            pass


def grab_monitor(monitor: int) -> tuple[np.ndarray, tuple[int, int]]:
    """Full-monitor screenshot (BGR) for the calibration tool."""
    with _new_mss() as s:
        mons = s.monitors
        m = mons[monitor] if 1 <= monitor < len(mons) else mons[1]
        arr = np.ascontiguousarray(np.asarray(s.grab(m))[:, :, :3])
        return arr, (int(m["width"]), int(m["height"]))


def list_monitors() -> list[str]:
    with _new_mss() as s:
        return [f"Monitor {i}: {m['width']}x{m['height']} @ ({m['left']},{m['top']})"
                for i, m in enumerate(s.monitors) if i > 0]
