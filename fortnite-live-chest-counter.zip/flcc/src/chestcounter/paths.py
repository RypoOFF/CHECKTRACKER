"""Filesystem locations. Portable mode: if ``portable.txt`` sits next to the .exe,
all data is stored in ``./data`` next to it; otherwise in %APPDATA%."""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_DIR_NAME = "FortniteLiveChestCounter"


def app_root() -> Path:
    """Folder containing the executable (frozen) or the repository root (dev)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def resource_path(relative: str) -> Path:
    """Path of a bundled read-only resource (works inside a PyInstaller bundle)."""
    base = Path(getattr(sys, "_MEIPASS", app_root()))
    return base / relative


def data_dir() -> Path:
    override = os.environ.get("FLCC_DATA_DIR")
    if override:
        path = Path(override)
    elif (app_root() / "portable.txt").exists():
        path = app_root() / "data"
    else:
        base = os.environ.get("APPDATA") or str(Path.home() / ".config")
        path = Path(base) / APP_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path() -> Path:
    return data_dir() / "stats.sqlite3"


def config_path() -> Path:
    return data_dir() / "config.json"


def log_dir() -> Path:
    p = data_dir() / "logs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def templates_dir() -> Path:
    p = data_dir() / "templates"
    p.mkdir(parents=True, exist_ok=True)
    return p
