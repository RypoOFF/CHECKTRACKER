"""System-wide hotkeys via the Win32 RegisterHotKey API (no keyboard hook, nothing
injected anywhere). On other platforms this is a harmless no-op."""
from __future__ import annotations

import logging
import sys
import threading
from typing import Callable

log = logging.getLogger(__name__)

MOD = {"ALT": 0x1, "CTRL": 0x2, "SHIFT": 0x4, "META": 0x8, "WIN": 0x8}
KEYS = {**{chr(c): c for c in range(ord("A"), ord("Z") + 1)},
        **{str(d): ord(str(d)) for d in range(10)},
        **{f"F{i}": 0x6F + i for i in range(1, 13)},
        "UP": 0x26, "DOWN": 0x28, "LEFT": 0x25, "RIGHT": 0x27, "SPACE": 0x20,
        "HOME": 0x24, "END": 0x23, "PGUP": 0x21, "PGDOWN": 0x22, "INS": 0x2D, "DEL": 0x2E}


def parse_hotkey(text: str) -> tuple[int, int] | None:
    """'Ctrl+Alt+O' -> (modifiers, vk) or None if invalid/unsupported."""
    mods, vk = 0, None
    for part in (p.strip().upper() for p in text.split("+") if p.strip()):
        if part in MOD:
            mods |= MOD[part]
        elif part in KEYS and vk is None:
            vk = KEYS[part]
        else:
            return None
    return (mods, vk) if vk is not None and mods else None


class HotkeyManager:
    def __init__(self):
        self._thread: threading.Thread | None = None
        self._tid = 0
        self.failed: list[str] = []

    @property
    def available(self) -> bool:
        return sys.platform == "win32"

    def register(self, mapping: dict[str, tuple[str, Callable[[], None]]]) -> list[str]:
        """mapping: action -> (hotkey text, callback). Returns a list of failures."""
        self.stop()
        self.failed = []
        if not self.available:
            return []
        parsed = {}
        for action, (text, cb) in mapping.items():
            p = parse_hotkey(text)
            if p is None:
                self.failed.append(f"{action}: invalid hotkey '{text}'")
            else:
                parsed[len(parsed) + 1] = (action, text, p, cb)
        ready = threading.Event()
        self._thread = threading.Thread(target=self._loop, args=(parsed, ready), daemon=True,
                                        name="Hotkeys")
        self._thread.start()
        ready.wait(2)
        return self.failed

    def stop(self) -> None:
        if self._thread and self._tid and self.available:
            import ctypes
            ctypes.windll.user32.PostThreadMessageW(self._tid, 0x0012, 0, 0)  # WM_QUIT
            self._thread.join(1)
        self._thread, self._tid = None, 0

    def _loop(self, parsed, ready: threading.Event) -> None:
        import ctypes
        from ctypes import wintypes
        u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
        self._tid = k32.GetCurrentThreadId()
        for hid, (action, text, (mods, vk), _) in parsed.items():
            if not u32.RegisterHotKey(None, hid, mods | 0x4000, vk):  # MOD_NOREPEAT
                self.failed.append(f"{action}: '{text}' is already used by another program")
        ready.set()
        msg = wintypes.MSG()
        while u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            if msg.message == 0x0312 and msg.wParam in parsed:  # WM_HOTKEY
                try:
                    parsed[msg.wParam][3]()
                except Exception:
                    log.exception("hotkey callback failed")
        for hid in parsed:
            u32.UnregisterHotKey(None, hid)
