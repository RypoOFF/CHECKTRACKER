"""Rotating file log + a dedicated 'detection' logger."""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from . import paths


def setup_logging(debug: bool = False) -> None:
    root = logging.getLogger()
    if getattr(root, "_flcc_ready", False):
        return
    root.setLevel(logging.DEBUG if debug else logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    try:
        for name, level in (("app.log", logging.INFO), ("detection.log", logging.DEBUG)):
            h = RotatingFileHandler(paths.log_dir() / name, maxBytes=1_000_000,
                                    backupCount=3, encoding="utf-8")
            h.setFormatter(fmt)
            h.setLevel(level)
            if name == "detection.log":
                h.addFilter(lambda r: r.name.startswith("chestcounter.detection"))
            root.addHandler(h)
    except OSError:  # read-only location: keep running without file logs
        pass
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root.addHandler(sh)
    root._flcc_ready = True  # type: ignore[attr-defined]
