"""Typed, JSON-persisted configuration with forward-compatible loading."""
from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class DetectionConfig:
    enabled: bool = True
    fps: float = 8.0                       # analysis frequency (frames/s)
    monitor: int = 1                       # mss monitor index (1 = primary)
    # Region of interest as fractions of the monitor: x, y, w, h
    roi: list[float] = field(default_factory=lambda: [0.30, 0.45, 0.40, 0.35])
    match_threshold: float = 0.72          # template score to consider "prompt visible"
    scales: list[float] = field(default_factory=lambda: [0.93, 1.0, 1.07])
    arm_frames: int = 2                    # consecutive frames to arm
    release_frames: int = 2                # consecutive misses to consider prompt gone
    confirm_window_s: float = 1.5          # wait for 'opened' evidence after prompt loss
    flicker_gap_s: float = 0.6             # prompt reappearing within this gap = same chest
    min_dwell_s: float = 0.12
    use_interact_key: bool = True          # read key state (GetAsyncKeyState), no hook
    interact_key: str = "E"
    press_to_loss_max_s: float = 1.5
    min_confidence: float = 0.55           # below => logged but NOT counted
    cooldown_s: float = 1.5                # global dedupe lockout after a counted chest
    # Session lifecycle
    auto_session: bool = True
    inactivity_end_s: float = 600.0
    end_on_game_close: bool = True
    process_names: list[str] = field(default_factory=lambda: ["FortniteClient-Win64-Shipping.exe"])
    only_when_game_running: bool = True


@dataclass
class OverlayConfig:
    enabled: bool = True
    x: int = 40
    y: int = 40
    w: int = 260
    h: int = 150
    opacity: float = 0.92
    bg_alpha: float = 0.35
    font_scale: float = 1.0
    accent: str = "#8b5cf6"
    click_through: bool = False
    hide_when_game_closed: bool = False
    stats: list[str] = field(default_factory=lambda: ["chests", "cpm", "timer"])


@dataclass
class HotkeyConfig:
    toggle_overlay: str = "Ctrl+Alt+O"
    toggle_detection: str = "Ctrl+Alt+P"
    add_chest: str = "Ctrl+Alt+Up"
    remove_chest: str = "Ctrl+Alt+Down"
    toggle_session: str = "Ctrl+Alt+S"


@dataclass
class UiConfig:
    language: str = "en"
    accent: str = "#8b5cf6"
    chart_points: int = 120


@dataclass
class AppConfig:
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    overlay: OverlayConfig = field(default_factory=OverlayConfig)
    hotkeys: HotkeyConfig = field(default_factory=HotkeyConfig)
    ui: UiConfig = field(default_factory=UiConfig)
    debug: bool = False

    # -- persistence -------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppConfig":
        cfg = cls()
        for f in fields(cls):
            raw = data.get(f.name)
            cur = getattr(cfg, f.name)
            if isinstance(raw, dict) and hasattr(cur, "__dataclass_fields__"):
                valid = {x.name for x in fields(cur)}
                for k, v in raw.items():
                    if k in valid:  # ignore unknown keys: forward/backward compatible
                        setattr(cur, k, v)
            elif f.name == "debug" and isinstance(raw, bool):
                cfg.debug = raw
        return cfg

    def save(self, path: Path) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, path: Path) -> "AppConfig":
        try:
            return cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except FileNotFoundError:
            return cls()
        except (OSError, ValueError) as exc:
            log.warning("Config unreadable (%s); using defaults", exc)
            bad = path.with_suffix(".corrupt")
            try:
                path.replace(bad)
            except OSError:
                pass
            return cls()
