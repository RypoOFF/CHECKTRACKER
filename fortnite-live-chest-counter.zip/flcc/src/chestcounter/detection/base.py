"""Plug-in interface so new recognition models (templates, YOLO, OCR…) can be added."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

import numpy as np


@dataclass
class Observation:
    """What a recogniser saw in ONE frame."""
    ts: float
    prompt_score: float = 0.0          # best 'chest can be opened' score (0..1)
    prompt_kind: str = "normal"
    opened_score: float = 0.0          # best 'chest is open' evidence (0..1)
    interact_pressed_ts: float | None = None   # last time the interact key was seen down
    extra: dict = field(default_factory=dict)


class Recogniser(Protocol):
    """A recogniser turns a BGR/gray ROI image into an Observation."""
    name: str

    def observe(self, roi_bgr: np.ndarray, frame_height: int, ts: float) -> Observation: ...
    def reload(self) -> None: ...
    def is_ready(self) -> bool: ...
