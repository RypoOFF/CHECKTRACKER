"""Background worker: game watching, capture → recognise → state machine → counter."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Callable

import psutil

from ..config import DetectionConfig
from ..session import SessionManager
from .base import Recogniser
from .keystate import KeyWatcher
from .state_machine import ChestStateMachine

log = logging.getLogger("chestcounter.detection.engine")


@dataclass
class EngineStatus:
    game_running: bool = False
    paused: bool = False
    ready: bool = False              # at least one 'prompt' template available
    fsm_state: str = "idle"
    prompt_score: float = 0.0
    opened_score: float = 0.0
    threshold: float = 0.0
    last_confidence: float | None = None
    last_decision: str = ""
    fps: float = 0.0
    frame_ms: float = 0.0
    error: str = ""
    warning: str = ""
    log: list[str] = field(default_factory=list)


class GameWatcher:
    def __init__(self, names: Callable[[], list[str]], interval: float = 3.0):
        self._names, self.interval = names, interval
        self._last = 0.0
        self._running = False

    def running(self) -> bool:
        now = time.monotonic()
        if now - self._last >= self.interval:
            self._last = now
            wanted = {n.lower() for n in self._names()}
            try:
                self._running = any((p.info["name"] or "").lower() in wanted
                                    for p in psutil.process_iter(["name"]))
            except Exception:
                log.exception("process scan failed")
        return self._running


class DetectionEngine(threading.Thread):
    def __init__(self, cfg: DetectionConfig, recogniser: Recogniser, sessions: SessionManager,
                 keys: KeyWatcher, source_factory: Callable[[], object],
                 on_status: Callable[[EngineStatus], None] | None = None,
                 watcher: GameWatcher | None = None):
        super().__init__(name="DetectionEngine", daemon=True)
        self.cfg, self.rec, self.sessions, self.keys = cfg, recogniser, sessions, keys
        self.source_factory = source_factory
        self.on_status = on_status or (lambda s: None)
        self.watcher = watcher or GameWatcher(lambda: self.cfg.process_names)
        self.status = EngineStatus(threshold=cfg.match_threshold)
        self.fsm = ChestStateMachine(cfg, has_opened_templates=False)
        self._halt = threading.Event()
        self._reconfigure = threading.Event()
        self._black_frames = 0

    # -- control ------------------------------------------------------------
    def stop(self) -> None:
        self._halt.set()

    def reconfigure(self) -> None:
        """Call after settings/templates changed (rebuilds capture region + FSM)."""
        self._reconfigure.set()

    def set_paused(self, paused: bool) -> None:
        self.cfg.enabled = not paused

    def toggle_pause(self) -> bool:
        self.cfg.enabled = not self.cfg.enabled
        return not self.cfg.enabled

    # -- helpers --------------------------------------------------------------
    def _log(self, msg: str) -> None:
        self.status.log.append(time.strftime("%H:%M:%S ") + msg)
        del self.status.log[:-60]

    def _publish(self) -> None:
        self.status.threshold = self.cfg.match_threshold
        self.status.paused = not self.cfg.enabled
        self.on_status(self.status)

    def _rebuild(self):
        self.rec.reload()
        has_opened = any(t.role == "opened" for t in getattr(self.rec, "lib", None).items) \
            if hasattr(self.rec, "lib") else False
        self.fsm = ChestStateMachine(self.cfg, has_opened)
        self.status.ready = self.rec.is_ready()
        self._reconfigure.clear()

    # -- main loop ------------------------------------------------------------
    def run(self) -> None:  # noqa: C901 (a flat loop is clearer than splitting here)
        source = None
        last_tick = last_pub = 0.0
        fps_t, fps_n = time.monotonic(), 0
        self._rebuild()
        while not self._halt.is_set():
            t0 = time.monotonic()
            try:
                game = self.watcher.running() if self.cfg.only_when_game_running else True
                self.status.game_running = game
                if time.monotonic() - last_tick >= 1.0:
                    last_tick = time.monotonic()
                    self.sessions.tick(game)
                if self._reconfigure.is_set():
                    self._rebuild()
                    if source:
                        source.close()
                        source = None
                active = self.cfg.enabled and game and self.status.ready
                if not active:
                    if source:
                        source.close()
                        source = None
                    self.fsm.reset()
                    self.status.fsm_state, self.status.fps, self.status.frame_ms = "idle", 0.0, 0.0
                    self.status.prompt_score = self.status.opened_score = 0.0
                    if t0 - last_pub >= 0.5:
                        last_pub = t0
                        self._publish()
                    self._halt.wait(0.25)
                    continue

                if source is None:
                    source = self.source_factory()
                    self.status.error = ""
                roi, frame_h = source.grab()
                ts = time.time()
                self._check_black(roi)
                self.keys.set_key(self.cfg.interact_key)
                obs = self.rec.observe(roi, frame_h, ts)
                obs.interact_pressed_ts = self.keys.last_down_ts if self.cfg.use_interact_key else None
                self.status.prompt_score, self.status.opened_score = obs.prompt_score, obs.opened_score
                cand = self.fsm.update(obs)
                self.status.fsm_state = self.fsm.state.value
                if cand is not None:
                    self._handle(cand)
            except Exception as exc:  # never let the worker die: back off and retry
                log.exception("engine error")
                self.status.error = f"{type(exc).__name__}: {exc}"
                if source:
                    try:
                        source.close()
                    except Exception:
                        pass
                    source = None
                self._halt.wait(1.0)
            # pacing
            now = time.monotonic()
            self.status.frame_ms = (now - t0) * 1000
            fps_n += 1
            if now - fps_t >= 1.0:
                self.status.fps = fps_n / (now - fps_t)
                fps_t, fps_n = now, 0
            if now - last_pub >= 0.12:
                last_pub = now
                self._publish()
            self._halt.wait(max(0.0, 1.0 / max(0.5, self.cfg.fps) - (now - t0)))
        if source:
            source.close()

    def _handle(self, cand) -> None:
        self.status.last_confidence = cand.confidence
        res = self.sessions.add_detection(cand.kind, cand.confidence, cand.ts,
                                          details="; ".join(cand.reasons))
        self.status.last_decision = res.reason
        self._log(f"{res.reason.upper():<15} conf={cand.confidence:.2f} kind={cand.kind} "
                  f"({cand.reasons[1] if len(cand.reasons) > 1 else ''})")

    def _check_black(self, roi) -> None:
        if float(roi.mean()) < 1.5:
            self._black_frames += 1
        else:
            self._black_frames = 0
        self.status.warning = ("Captured frames are black. Switch Fortnite to 'Windowed Fullscreen' "
                               "(exclusive fullscreen can block screen capture).") \
            if self._black_frames > self.cfg.fps * 5 else ""
