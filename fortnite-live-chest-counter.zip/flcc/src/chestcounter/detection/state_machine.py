"""Chest-open state machine (pure logic, no I/O -> deterministic & unit-tested).

Why not "count whenever a closed chest is visible"?  Because a chest stays on screen
long after it is opened (or before), which would count it again and again.
We instead count a *transition*:

    IDLE --prompt seen for N frames--> ARMED --prompt disappears--> PENDING --> decision

The "open chest" prompt only exists while the player can interact with a *closed* chest,
so it appears once per approach.  The decision combines evidence into a confidence:

  * prompt quality            (template score)
  * interact key pressed shortly before the prompt vanished   (strong evidence)
  * an 'opened' template seen right after the prompt vanished (strong evidence)

Walking away from a chest makes the prompt vanish with *no* key press / opened evidence
-> low confidence -> rejected. That is the main false-positive defence.
"""
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass

from ..config import DetectionConfig
from .base import Observation

log = logging.getLogger("chestcounter.detection.fsm")


class State(enum.Enum):
    IDLE = "idle"
    ARMED = "armed"        # prompt visible: a closed chest is in interaction range
    PENDING = "pending"    # prompt just vanished: waiting for confirmation evidence


@dataclass
class Candidate:
    ts: float
    kind: str
    confidence: float
    reasons: list[str]

    def describe(self) -> str:
        return f"kind={self.kind} conf={self.confidence:.2f} [{', '.join(self.reasons)}]"


class ChestStateMachine:
    def __init__(self, cfg: DetectionConfig, has_opened_templates: bool = False):
        self.cfg = cfg
        self.has_opened = has_opened_templates
        self.state = State.IDLE
        self._hits = 0
        self._misses = 0
        self._armed_at = 0.0
        self._lost_at = 0.0
        self._best_prompt = 0.0
        self._kind = "normal"
        self._last_press: float | None = None
        self._opened_seen = 0.0
        self.last_candidate: Candidate | None = None

    def reset(self) -> None:
        self.__init__(self.cfg, self.has_opened)  # type: ignore[misc]

    # ----------------------------------------------------------------------
    def update(self, obs: Observation) -> Candidate | None:
        """Feed one observation. Returns a Candidate when a decision is made
        (the caller applies the confidence threshold and global dedupe)."""
        c = self.cfg
        visible = obs.prompt_score >= c.match_threshold
        if obs.interact_pressed_ts is not None:
            self._last_press = obs.interact_pressed_ts

        if self.state is State.IDLE:
            self._hits = self._hits + 1 if visible else 0
            if self._hits >= c.arm_frames:
                self._arm(obs)
            return None

        if self.state is State.ARMED:
            if visible:
                self._misses = 0
                if obs.prompt_score > self._best_prompt:
                    self._best_prompt, self._kind = obs.prompt_score, obs.prompt_kind
                self._opened_seen = max(self._opened_seen, obs.opened_score)
                return None
            self._misses += 1
            if self._misses >= c.release_frames:
                self.state = State.PENDING
                self._lost_at = obs.ts
                self._opened_seen = max(self._opened_seen, obs.opened_score)
            return None

        # PENDING -----------------------------------------------------------
        if visible:
            # Flicker (occlusion/anim): same chest if it comes back quickly.
            if obs.ts - self._lost_at <= c.flicker_gap_s:
                self.state, self._misses = State.ARMED, 0
                return None
            # A *different* prompt appeared after a longer gap: decide first, then re-arm.
            cand = self._decide(obs.ts)
            self._arm(obs)
            return cand
        self._opened_seen = max(self._opened_seen, obs.opened_score)
        wait = c.confirm_window_s if self.has_opened else max(c.confirm_window_s * 0.5, 0.3)
        if obs.ts - self._lost_at >= wait:
            cand = self._decide(obs.ts)
            self.state, self._hits = State.IDLE, 0
            return cand
        return None

    # ----------------------------------------------------------------------
    def _arm(self, obs: Observation) -> None:
        self.state = State.ARMED
        self._armed_at, self._misses = obs.ts, 0
        self._best_prompt, self._kind = obs.prompt_score, obs.prompt_kind
        self._opened_seen = obs.opened_score
        self._last_press = None if self._last_press is None or self._last_press < obs.ts - 5 else self._last_press
        self._hits = 0

    def _decide(self, now: float) -> Candidate | None:
        c = self.cfg
        dwell = self._lost_at - self._armed_at
        reasons: list[str] = []
        if dwell < c.min_dwell_s:
            reasons.append(f"dwell {dwell:.2f}s too short")
            self.last_candidate = Candidate(now, self._kind, 0.0, reasons)
            return self.last_candidate

        # Weights: prompt quality 0.30 | key 0.40 | opened 0.30 (re-distributed if a source is off)
        quality = min(1.0, max(0.0, (self._best_prompt - c.match_threshold) / max(1e-6, 1 - c.match_threshold)))
        conf = 0.18 + 0.12 * quality
        reasons.append(f"prompt {self._best_prompt:.2f}")

        if c.use_interact_key:
            if self._last_press is not None and \
                    self._armed_at - 0.6 <= self._last_press <= self._lost_at + 0.3 and \
                    0.0 <= self._lost_at - self._last_press <= c.press_to_loss_max_s:
                conf += 0.40
                reasons.append("interact key pressed just before prompt vanished")
            else:
                reasons.append("no interact key press -> likely walked away")
        else:
            conf += 0.05  # no key evidence: cannot tell 'opened' from 'walked away'
            reasons.append("key evidence disabled (weak)")

        if self.has_opened:
            if self._opened_seen >= c.match_threshold:
                conf += 0.30
                reasons.append(f"opened evidence {self._opened_seen:.2f}")
            else:
                reasons.append("no opened evidence")
        else:
            conf += 0.15

        cand = Candidate(now, self._kind, min(1.0, conf), reasons)
        self.last_candidate = cand
        log.info("candidate %s", cand.describe())
        return cand
