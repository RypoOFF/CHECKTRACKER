"""Template library + OpenCV matcher (the default recogniser).

Templates are small PNG crops of on-screen elements, captured by the user through
the calibration tool (so they match the user's resolution, language and HUD scale).

File layout:  templates/<role>/<kind>__<name>__h<referenceHeight>.png
  role: prompt (chest can be opened) | opened (optional evidence that it just opened)
  kind: normal | rare | special | ... (free text, shown in stats)
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from .base import Observation

log = logging.getLogger("chestcounter.detection.templates")

ROLES = ("prompt", "opened")
_NAME_RE = re.compile(r"^(?P<kind>[^_]+)__(?P<name>.+)__h(?P<h>\d+)$")


@dataclass
class Template:
    role: str
    kind: str
    name: str
    ref_height: int
    gray: np.ndarray
    path: Path


def _to_gray(img: np.ndarray) -> np.ndarray:
    if img.ndim == 3:
        return cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY if img.shape[2] == 4 else cv2.COLOR_BGR2GRAY)
    return img


class TemplateLibrary:
    def __init__(self, root: Path):
        self.root = root
        self.items: list[Template] = []
        self.reload()

    def reload(self) -> None:
        items: list[Template] = []
        for role in ROLES:
            d = self.root / role
            d.mkdir(parents=True, exist_ok=True)
            for f in sorted(d.glob("*.png")):
                m = _NAME_RE.match(f.stem)
                if not m:
                    log.warning("Ignoring template with bad name: %s", f.name)
                    continue
                data = cv2.imdecode(np.fromfile(str(f), dtype=np.uint8), cv2.IMREAD_UNCHANGED)
                if data is None or min(data.shape[:2]) < 6:
                    log.warning("Unreadable/too small template: %s", f.name)
                    continue
                items.append(Template(role, m["kind"], m["name"], int(m["h"]), _to_gray(data), f))
        self.items = items
        log.info("Loaded %d templates", len(items))

    def by_role(self, role: str) -> list[Template]:
        return [t for t in self.items if t.role == role]

    def add(self, role: str, kind: str, bgr: np.ndarray, ref_height: int) -> Path:
        if role not in ROLES:
            raise ValueError(f"unknown role {role}")
        kind = re.sub(r"[^A-Za-z0-9-]", "", kind) or "normal"
        d = self.root / role
        d.mkdir(parents=True, exist_ok=True)
        name = time.strftime("%Y%m%d%H%M%S")
        path = d / f"{kind}__{name}__h{ref_height}.png"
        ok, buf = cv2.imencode(".png", bgr)
        if not ok:
            raise RuntimeError("PNG encoding failed")
        buf.tofile(str(path))
        self.reload()
        return path

    def remove(self, tpl: Template) -> None:
        tpl.path.unlink(missing_ok=True)
        self.reload()


class TemplateRecogniser:
    """Multi-scale normalised cross-correlation on a (small) region of interest."""
    name = "template"

    def __init__(self, library: TemplateLibrary, scales: list[float]):
        self.lib = library
        self.scales = scales or [1.0]
        self._cache: dict[tuple[Path, int, float], np.ndarray] = {}

    def reload(self) -> None:
        self.lib.reload()
        self._cache.clear()

    def is_ready(self) -> bool:
        return bool(self.lib.by_role("prompt"))

    def _scaled(self, t: Template, frame_h: int, s: float) -> np.ndarray:
        key = (t.path, frame_h, s)
        img = self._cache.get(key)
        if img is None:
            f = max(0.05, frame_h / t.ref_height * s)
            img = cv2.resize(t.gray, None, fx=f, fy=f,
                             interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_LINEAR)
            self._cache[key] = img
        return img

    def _best(self, role: str, gray: np.ndarray, frame_h: int) -> tuple[float, str]:
        best, kind = 0.0, "normal"
        for t in self.lib.by_role(role):
            for s in self.scales:
                tpl = self._scaled(t, frame_h, s)
                if tpl.shape[0] > gray.shape[0] or tpl.shape[1] > gray.shape[1]:
                    continue
                if float(tpl.std()) < 4.0:      # flat template => meaningless correlation
                    continue
                res = cv2.matchTemplate(gray, tpl, cv2.TM_CCOEFF_NORMED)
                score = float(res.max())
                if np.isfinite(score) and score > best:
                    best, kind = score, t.kind
        return max(0.0, best), kind

    def observe(self, roi_bgr: np.ndarray, frame_height: int, ts: float) -> Observation:
        gray = _to_gray(roi_bgr)
        p, kind = self._best("prompt", gray, frame_height)
        o = self._best("opened", gray, frame_height)[0] if self.lib.by_role("opened") else 0.0
        return Observation(ts=ts, prompt_score=p, prompt_kind=kind, opened_score=o)
