"""Interact-key state watcher.

Uses GetAsyncKeyState polling (no hooks, no injection, nothing touches the game
process): it only answers "was the key held down recently?". Windows only; on other
platforms it never reports a press (so the app degrades gracefully / tests run).
"""
from __future__ import annotations

import sys
import threading
import time

_VK = {**{chr(c): c for c in range(ord("A"), ord("Z") + 1)},
       **{str(d): ord(str(d)) for d in range(10)},
       "SPACE": 0x20, "SHIFT": 0x10, "CTRL": 0x11, "ALT": 0x12, "ENTER": 0x0D, "TAB": 0x09,
       **{f"F{i}": 0x6F + i for i in range(1, 13)}}


def vk_from_name(name: str) -> int | None:
    return _VK.get(name.strip().upper())


class KeyWatcher:
    def __init__(self, key_name: str = "E", poll_hz: float = 100.0):
        self.key_name = key_name
        self.poll = 1.0 / poll_hz
        self.last_down_ts: float | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.available = sys.platform == "win32"

    def set_key(self, name: str) -> None:
        self.key_name = name

    def start(self) -> None:
        if not self.available or self._thread:
            return
        self._thread = threading.Thread(target=self._run, name="KeyWatcher", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        import ctypes
        get = ctypes.windll.user32.GetAsyncKeyState  # type: ignore[attr-defined]
        while not self._stop.is_set():
            vk = vk_from_name(self.key_name)
            if vk is not None and get(vk) & 0x8000:
                self.last_down_ts = time.time()
            time.sleep(self.poll)

    # test helper
    def simulate_press(self, ts: float | None = None) -> None:
        self.last_down_ts = ts or time.time()
