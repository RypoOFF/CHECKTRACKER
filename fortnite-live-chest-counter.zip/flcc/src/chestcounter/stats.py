"""Pure statistics helpers (no Qt, no I/O) so they are easy to unit-test."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from .db import EventRow, SessionRow


@dataclass
class LiveStats:
    total: int = 0
    elapsed: float = 0.0
    per_minute: float = 0.0
    rolling_per_minute: float = 0.0     # last 5 minutes
    avg_interval: float | None = None   # seconds between consecutive chests
    kinds: dict[str, int] = field(default_factory=dict)


def compute_live(events: Sequence[EventRow], started_at: float, now: float,
                 rolling_window: float = 300.0) -> LiveStats:
    elapsed = max(0.0, now - started_at)
    adds = [e for e in events if e.delta > 0]
    total = sum(e.delta for e in events)
    kinds: dict[str, int] = {}
    for e in events:
        kinds[e.kind] = kinds.get(e.kind, 0) + e.delta
    kinds = {k: v for k, v in kinds.items() if v > 0}
    per_min = (total / (elapsed / 60.0)) if elapsed >= 30 and total > 0 else 0.0
    window = min(rolling_window, elapsed)
    recent = sum(e.delta for e in events if e.ts >= now - window)
    rolling = (recent / (window / 60.0)) if window >= 30 and recent > 0 else 0.0
    times = sorted(e.ts for e in adds)
    avg = None
    if len(times) >= 2:
        avg = (times[-1] - times[0]) / (len(times) - 1)
    return LiveStats(total, elapsed, per_min, rolling, avg, kinds)


def cumulative_series(events: Sequence[EventRow], started_at: float,
                      end: float) -> list[tuple[float, int]]:
    """[(minutes since start, running total)] including start and end points."""
    pts: list[tuple[float, int]] = [(0.0, 0)]
    run = 0
    for e in sorted(events, key=lambda x: (x.ts, x.id)):
        run += e.delta
        pts.append((max(0.0, (e.ts - started_at) / 60.0), run))
    pts.append((max(pts[-1][0], (end - started_at) / 60.0), run))
    return pts


@dataclass
class HistoryStats:
    sessions: int = 0
    total: int = 0
    average: float = 0.0
    best: int = 0
    best_session_id: int | None = None
    best_per_minute: float = 0.0


def compute_history(sessions: Sequence[SessionRow]) -> HistoryStats:
    done = [s for s in sessions if s.ended_at is not None]
    if not done:
        return HistoryStats()
    best = max(done, key=lambda s: s.total)
    rates = [s.total / (s.duration / 60.0) for s in done if s.duration and s.duration >= 60]
    return HistoryStats(len(done), sum(s.total for s in done),
                        sum(s.total for s in done) / len(done),
                        best.total, best.id, max(rates) if rates else 0.0)


def fmt_duration(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    s = int(max(0, seconds))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"
