import sys
from chestcounter.app import main

if __name__ == "__main__":
    sys.exit(main())
