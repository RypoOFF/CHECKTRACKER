from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QIcon
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QMenu, QPushButton,
                               QStackedWidget, QSystemTrayIcon, QVBoxLayout, QWidget)

from .. import APP_NAME, __version__, paths
from . import theme
from .overlay import Overlay
from .pages import DashboardPage, HistoryPage, LivePage, SettingsPage


class MainWindow(QMainWindow):
    def __init__(self, ctl):
        super().__init__()
        self.ctl = ctl
        self.setWindowTitle(f"{APP_NAME} {__version__}")
        self.resize(1180, 780)
        icon_path = paths.resource_path("assets/icon.ico")
        self.icon = QIcon(str(icon_path)) if icon_path.exists() else QIcon()
        self.setWindowIcon(self.icon)
        self.overlay = Overlay(ctl.cfg.overlay, ctl)
        self._really_quit = False

        root = QWidget(); root.setObjectName("root"); self.setCentralWidget(root)
        lay = QHBoxLayout(root); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        side = QFrame(); side.setObjectName("sidebar"); side.setFixedWidth(200)
        sl = QVBoxLayout(side); sl.setContentsMargins(12, 18, 12, 14); sl.setSpacing(4)
        brand = QLabel("CHEST COUNTER"); brand.setObjectName("brand"); sl.addWidget(brand)
        sub = QLabel(f"Live • v{__version__}"); sub.setObjectName("muted"); sl.addWidget(sub); sl.addSpacing(16)
        self.stack = QStackedWidget()
        self.pages = [("Dashboard", DashboardPage(ctl)), ("Live Tracker", LivePage(ctl)), ("History", HistoryPage(ctl)),
                      ("Settings", SettingsPage(ctl, self.overlay, self))]
        self.nav: list[QPushButton] = []
        for i, (name, page) in enumerate(self.pages):
            b = QPushButton(name); b.setObjectName("nav"); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, i=i: self.go(i)); sl.addWidget(b); self.nav.append(b); self.stack.addWidget(page)
        sl.addStretch()
        self.status = QLabel(""); self.status.setObjectName("muted"); self.status.setWordWrap(True); sl.addWidget(self.status)
        lay.addWidget(side); lay.addWidget(self.stack, 1)
        self.go(0); self.apply_theme()

        self._setup_tray()
        ctl.hotkey_overlay.connect(self.toggle_overlay)
        ctl.hotkey_detection.connect(ctl.toggle_pause)
        ctl.hotkey_add.connect(lambda: ctl.sessions.adjust(+1))
        ctl.hotkey_remove.connect(lambda: ctl.sessions.adjust(-1))
        ctl.hotkey_session.connect(ctl.toggle_session)
        ctl.toast.connect(self.show_toast)
        ctl.status_changed.connect(self._on_status)
        if ctl.cfg.overlay.enabled and not ctl.cfg.overlay.hide_when_game_closed:
            self.overlay.show()

    def go(self, i: int) -> None:
        self.stack.setCurrentIndex(i)
        for j, b in enumerate(self.nav): b.setChecked(j == i)

    def apply_theme(self) -> None:
        acc = self.ctl.cfg.ui.accent
        QApplication.instance().setStyleSheet(theme.stylesheet(acc))
        for _, p in self.pages:
            for w in p.findChildren(QWidget):
                if hasattr(w, "set_accent"): w.set_accent(acc)

    def toggle_overlay(self) -> None:
        self.overlay.toggle()

    def _on_status(self, st) -> None:
        txt = "paused" if st.paused else "waiting for Fortnite" if not st.game_running else \
              "needs calibration" if not st.ready else f"detecting ({st.fsm_state})"
        self.status.setText(f"Detection: {txt}")

    # -- tray -----------------------------------------------------------------
    def _setup_tray(self) -> None:
        self.tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(self.icon, self)
        m = QMenu()
        for text, fn in (("Open", self.showNormal), ("Show / hide overlay", self.toggle_overlay),
                         ("Pause / resume detection", self.ctl.toggle_pause),
                         ("Unlock overlay (disable click-through)", self._unlock_overlay),
                         ("Quit", self.quit)):
            a = QAction(text, m); a.triggered.connect(lambda _=False, f=fn: f()); m.addAction(a)
        self.tray.setContextMenu(m); self.tray.setToolTip(APP_NAME)
        self.tray.activated.connect(lambda r: self.showNormal() if r == QSystemTrayIcon.Trigger else None)
        self.tray.show()

    def _unlock_overlay(self) -> None:
        self.ctl.cfg.overlay.click_through = False
        self.overlay.apply_config(); self.ctl.save_and_apply()

    def show_toast(self, text: str) -> None:
        if self.tray:
            self.tray.showMessage(APP_NAME, text, QSystemTrayIcon.Information, 2500)
        self.status.setText(text); QTimer.singleShot(4000, lambda: self._on_status(self.ctl.last_status))

    def quit(self) -> None:
        self._really_quit = True
        self.overlay.close()
        self.ctl.shutdown()
        QApplication.instance().quit()

    def closeEvent(self, e) -> None:
        if self.tray and not self._really_quit:
            e.ignore(); self.hide()  # keep counting in the background (tray)
            self.show_toast("Still running in the tray. Right-click the icon to quit.")
        else:
            e.accept()
