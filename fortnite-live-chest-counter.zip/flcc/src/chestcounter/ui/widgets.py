from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPointF, QRectF, Qt, QVariantAnimation
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QFrame, QLabel, QSizePolicy, QVBoxLayout, QWidget

from . import theme


class Card(QFrame):
    """Small titled value card."""
    def __init__(self, title: str, value: str = "—", parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(2)
        self.title = QLabel(title.upper()); self.title.setObjectName("cardTitle")
        self.value = QLabel(value); self.value.setObjectName("cardValue")
        lay.addWidget(self.title); lay.addWidget(self.value)

    def set(self, text: str) -> None:
        self.value.setText(text)


class CounterWidget(QFrame):
    """Huge animated counter."""
    def __init__(self, accent: str = "#8b5cf6", parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.accent = QColor(accent)
        self._value = 0
        self._pulse = 0.0
        self.setMinimumHeight(190)
        self._anim = QVariantAnimation(self, startValue=1.0, endValue=0.0, duration=550)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim)
        self.caption = "CHESTS OPENED"

    def _on_anim(self, v):
        self._pulse = float(v); self.update()

    def set_accent(self, c: str) -> None:
        self.accent = QColor(c); self.update()

    def set_value(self, v: int, animate: bool = True) -> None:
        if v != self._value and animate and v > self._value:
            self._anim.stop(); self._anim.start()
        self._value = v
        self.update()

    def paintEvent(self, e):
        super().paintEvent(e)
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = self.rect()
        p.setPen(QColor(theme.MUTED)); f = QFont(self.font()); f.setPointSize(10); f.setBold(True)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 2); p.setFont(f)
        p.drawText(QRectF(0, 14, r.width(), 20), Qt.AlignHCenter, self.caption)
        f = QFont(self.font()); f.setBold(True)
        f.setPixelSize(int(min(r.height() * 0.62, r.width() * 0.35) * (1 + 0.08 * self._pulse)))
        p.setFont(f)
        col = QColor(self.accent)
        col = col.lighter(100 + int(60 * self._pulse))
        p.setPen(col)
        p.drawText(QRectF(0, 28, r.width(), r.height() - 28), Qt.AlignCenter, str(self._value))


class LineChart(QWidget):
    """Lightweight cumulative line chart (no QtCharts dependency => smaller .exe)."""
    def __init__(self, accent: str = "#8b5cf6", parent=None):
        super().__init__(parent)
        self.accent = QColor(accent)
        self.points: list[tuple[float, float]] = []
        self.x_label = "min"
        self.setMinimumHeight(160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_accent(self, c: str) -> None:
        self.accent = QColor(c); self.update()

    def set_data(self, pts: list[tuple[float, float]]) -> None:
        self.points = pts; self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        ml, mr, mt, mb = 38, 12, 10, 24
        plot = QRectF(ml, mt, w - ml - mr, h - mt - mb)
        p.setPen(QColor(theme.MUTED)); small = QFont(self.font()); small.setPointSize(8); p.setFont(small)
        if len(self.points) < 2:
            p.drawText(self.rect(), Qt.AlignCenter, "No data yet")
            return
        xmax = max(0.5, max(x for x, _ in self.points))
        ymax = max(1, max(y for _, y in self.points))
        ymax = ymax + (1 if ymax < 5 else 0)
        grid = QPen(QColor(theme.BORDER)); grid.setWidth(1)
        for i in range(5):
            y = plot.top() + plot.height() * i / 4
            p.setPen(grid); p.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y))
            p.setPen(QColor(theme.MUTED))
            p.drawText(QRectF(0, y - 8, ml - 6, 16), Qt.AlignRight | Qt.AlignVCenter,
                       f"{ymax * (4 - i) / 4:.0f}")
        for i in range(0, 5):
            x = plot.left() + plot.width() * i / 4
            p.drawText(QRectF(x - 30, h - mb + 4, 60, 16), Qt.AlignCenter, f"{xmax * i / 4:.0f}{self.x_label}")

        def pt(x, y):
            return QPointF(plot.left() + x / xmax * plot.width(), plot.bottom() - y / ymax * plot.height())
        path = QPainterPath(pt(*self.points[0]))
        prev = self.points[0]
        for x, y in self.points[1:]:          # step line: a count only changes at an event
            path.lineTo(pt(x, prev[1])); path.lineTo(pt(x, y)); prev = (x, y)
        fill = QPainterPath(path); fill.lineTo(pt(prev[0], 0)); fill.lineTo(pt(self.points[0][0], 0)); fill.closeSubpath()
        g = QLinearGradient(0, plot.top(), 0, plot.bottom())
        c1, c2 = QColor(self.accent), QColor(self.accent)
        c1.setAlpha(110); c2.setAlpha(0)
        g.setColorAt(0, c1); g.setColorAt(1, c2)
        p.fillPath(fill, g)
        pen = QPen(self.accent); pen.setWidthF(2.2); pen.setJoinStyle(Qt.RoundJoin)
        p.setPen(pen); p.setBrush(Qt.NoBrush); p.drawPath(path)


class StatusDot(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.set("—", theme.MUTED)

    def set(self, text: str, color: str) -> None:
        self.setText(f"<span style='color:{color}'>●</span>&nbsp; {text}")
