"""Calibration: the user drags a rectangle on a screenshot of their own game to
define the detection region and to capture recognition templates."""
from __future__ import annotations

import numpy as np
from PySide6.QtCore import QPoint, QRect, Qt
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QComboBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QVBoxLayout, QWidget)

from ..detection.templates import ROLES


def bgr_to_pixmap(bgr: np.ndarray) -> QPixmap:
    h, w = bgr.shape[:2]
    img = QImage(bgr.data, w, h, bgr.strides[0], QImage.Format_BGR888).copy()
    return QPixmap.fromImage(img)


class SelectionCanvas(QWidget):
    def __init__(self, pix: QPixmap):
        super().__init__()
        self.pix = pix
        self.sel: QRect | None = None      # in widget coordinates
        self._start: QPoint | None = None
        self.setMinimumSize(640, 360)
        self.setCursor(Qt.CrossCursor)

    def _scale(self) -> float:
        return min(self.width() / self.pix.width(), self.height() / self.pix.height())

    def _origin(self) -> QPoint:
        s = self._scale()
        return QPoint(int((self.width() - self.pix.width() * s) / 2), int((self.height() - self.pix.height() * s) / 2))

    def selection_in_image(self) -> QRect | None:
        if not self.sel or self.sel.width() < 6 or self.sel.height() < 6:
            return None
        s, o = self._scale(), self._origin()
        r = self.sel.translated(-o)
        img = QRect(int(r.x() / s), int(r.y() / s), int(r.width() / s), int(r.height() / s))
        return img.intersected(self.pix.rect())

    def paintEvent(self, _):
        p = QPainter(self)
        s, o = self._scale(), self._origin()
        p.drawPixmap(QRect(o.x(), o.y(), int(self.pix.width() * s), int(self.pix.height() * s)), self.pix)
        if self.sel:
            p.setPen(QPen(QColor("#8b5cf6"), 2)); p.setBrush(QColor(139, 92, 246, 50)); p.drawRect(self.sel)

    def mousePressEvent(self, e):
        self._start = e.position().toPoint(); self.sel = QRect(self._start, self._start); self.update()

    def mouseMoveEvent(self, e):
        if self._start:
            self.sel = QRect(self._start, e.position().toPoint()).normalized(); self.update()

    def mouseReleaseEvent(self, e):
        self._start = None


class CalibrationDialog(QDialog):
    """mode: set detection region, or save a template (role + kind)."""
    def __init__(self, bgr: np.ndarray, controller, parent=None):
        super().__init__(parent)
        self.ctl, self.bgr = controller, bgr
        self.setWindowTitle("Calibration — drag a rectangle on the screenshot")
        self.resize(1100, 720)
        lay = QVBoxLayout(self)
        self.canvas = SelectionCanvas(bgr_to_pixmap(bgr))
        lay.addWidget(self.canvas, 1)
        row = QHBoxLayout()
        self.mode = QComboBox()
        self.mode.addItem("Detection region (where the 'open chest' prompt appears)", "roi")
        self.mode.addItem("Template: 'prompt' — chest CAN be opened (the interact prompt)", "prompt")
        self.mode.addItem("Template: 'opened' — optional proof that a chest just opened", "opened")
        self.kind = QLineEdit("normal"); self.kind.setPlaceholderText("kind: normal / rare / special…"); self.kind.setMaximumWidth(220)
        save = QPushButton("Save selection"); save.setObjectName("primary"); save.clicked.connect(self.save)
        close = QPushButton("Close"); close.clicked.connect(self.accept)
        row.addWidget(self.mode, 1); row.addWidget(QLabel("Kind:")); row.addWidget(self.kind); row.addWidget(save); row.addWidget(close)
        lay.addLayout(row)
        self.msg = QLabel("Tip: take the screenshot while the prompt is visible next to a closed chest. "
                          "Select ONLY the prompt (icon + text), tightly.")
        self.msg.setObjectName("muted"); self.msg.setWordWrap(True)
        lay.addWidget(self.msg)

    def save(self) -> None:
        r = self.canvas.selection_in_image()
        if r is None:
            self.msg.setText("Select a larger rectangle first."); return
        mode = self.mode.currentData()
        h, w = self.bgr.shape[:2]
        if mode == "roi":
            self.ctl.cfg.detection.roi = [round(r.x() / w, 4), round(r.y() / h, 4),
                                          round(r.width() / w, 4), round(r.height() / h, 4)]
            self.ctl.save_and_apply()
            self.msg.setText(f"Detection region saved: {r.width()}×{r.height()} px "
                             f"({r.width() * r.height() / (w * h):.1%} of the screen).")
        else:
            crop = np.ascontiguousarray(self.bgr[r.y():r.y() + r.height(), r.x():r.x() + r.width()])
            if crop.std() < 4:
                self.msg.setText("That area is almost flat/black — nothing to recognise there."); return
            path = self.ctl.library.add(mode, self.kind.text().strip() or "normal", crop, h)
            self.ctl.engine.reconfigure()
            self.msg.setText(f"Saved {mode} template: {path.name}")
