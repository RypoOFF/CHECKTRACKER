"""Transparent always-on-top overlay (frameless Qt window; no hooking of the game)."""
from __future__ import annotations

import time

from PySide6.QtCore import QPoint, QRect, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QWidget

from ..config import OverlayConfig
from ..stats import fmt_duration

STAT_LABELS = {
    "chests": "Chests", "cpm": "Chests / min", "rolling_cpm": "Last 5 min / min",
    "timer": "Time", "avg_interval": "Avg interval", "rare": "Rare / special", "status": "Detection",
}
GRIP = 16


class Overlay(QWidget):
    def __init__(self, cfg: OverlayConfig, controller):
        super().__init__(None)
        self.cfg, self.ctl = cfg, controller
        self._drag: QPoint | None = None
        self._resizing = False
        self._values: dict[str, str] = {}
        self._save_timer = QTimer(self, singleShot=True, interval=600)
        self._save_timer.timeout.connect(self._persist_geometry)
        self.setWindowTitle("Chest Counter Overlay")
        self.setMinimumSize(150, 80)
        self.apply_config()
        self._place()
        t = QTimer(self, interval=500); t.timeout.connect(self.refresh); t.start()
        controller.session_event.connect(lambda *_: self.refresh())
        self.refresh()

    # -- config -------------------------------------------------------------
    def apply_config(self) -> None:
        flags = Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.NoDropShadowWindowHint
        if self.cfg.click_through:
            flags |= Qt.WindowTransparentForInput
        was_visible = self.isVisible()
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)  # never steal focus from the game
        self.setWindowOpacity(max(0.2, min(1.0, self.cfg.opacity)))
        if was_visible:
            self.show()
        self.update()

    def _place(self) -> None:
        """Restore saved geometry, but only if it is still on a connected screen."""
        rect = QRect(self.cfg.x, self.cfg.y, self.cfg.w, self.cfg.h)
        if not any(s.availableGeometry().intersects(rect) for s in QGuiApplication.screens()):
            scr = QGuiApplication.primaryScreen().availableGeometry()
            rect.moveTopLeft(scr.topLeft() + QPoint(40, 40))
        self.setGeometry(rect)

    def reset_position(self) -> None:
        scr = QGuiApplication.primaryScreen().availableGeometry()
        self.setGeometry(QRect(scr.left() + 40, scr.top() + 40, 260, 150))
        self._persist_geometry()

    def _persist_geometry(self) -> None:
        g = self.geometry()
        self.cfg.x, self.cfg.y, self.cfg.w, self.cfg.h = g.x(), g.y(), g.width(), g.height()
        try:
            from .. import paths
            self.ctl.cfg.save(paths.config_path())
        except OSError:
            pass

    # -- data -----------------------------------------------------------------
    def refresh(self) -> None:
        sm, st = self.ctl.sessions, self.ctl.last_status
        s = sm.stats()
        v = {"chests": str(s.total) if sm.active else "0",
             "cpm": f"{s.per_minute:.2f}", "rolling_cpm": f"{s.rolling_per_minute:.2f}",
             "timer": fmt_duration(s.elapsed) if sm.active else "00:00",
             "avg_interval": fmt_duration(s.avg_interval) if s.avg_interval else "—",
             "rare": str(sum(n for k, n in s.kinds.items() if k != "normal")),
             "status": ("paused" if st.paused else "no game" if not st.game_running
                        else "not calibrated" if not st.ready else st.fsm_state)}
        if v != self._values:
            self._values = v
            self.update()
        if self.cfg.hide_when_game_closed and self.cfg.enabled:
            want = st.game_running
            if want != self.isVisible():
                self.setVisible(want)

    # -- painting -------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        bg = QColor(10, 11, 16, int(255 * self.cfg.bg_alpha))
        p.setBrush(bg); p.setPen(QPen(QColor(255, 255, 255, 25), 1)); p.drawRoundedRect(r, 14, 14)
        accent = QColor(self.cfg.accent)
        scale = max(0.5, min(r.width() / 260, r.height() / 150)) * self.cfg.font_scale
        stats = [k for k in self.cfg.stats if k in STAT_LABELS] or ["chests"]
        # hero stat first (large), the rest as compact rows
        hero, rest = stats[0], stats[1:]
        pad = 14 * scale
        f = QFont(self.font()); f.setBold(True); f.setPixelSize(max(8, int(11 * scale)))
        f.setLetterSpacing(QFont.AbsoluteSpacing, 1.5)
        p.setFont(f); p.setPen(QColor(255, 255, 255, 150))
        p.drawText(QRectF(pad, pad * 0.7, r.width() - 2 * pad, 16 * scale), Qt.AlignLeft, STAT_LABELS[hero].upper())
        f.setPixelSize(max(12, int(52 * scale))); f.setLetterSpacing(QFont.AbsoluteSpacing, 0)
        p.setFont(f); p.setPen(accent)
        top = pad * 0.7 + 14 * scale
        hero_h = 56 * scale
        p.drawText(QRectF(pad, top, r.width() - 2 * pad, hero_h), Qt.AlignLeft | Qt.AlignVCenter, self._values.get(hero, "—"))
        y = top + hero_h + 4 * scale
        f.setBold(False); f.setPixelSize(max(8, int(13 * scale))); p.setFont(f)
        row_h = 20 * scale
        for k in rest:
            if y + row_h > r.height() - 4:
                break
            p.setPen(QColor(255, 255, 255, 140))
            p.drawText(QRectF(pad, y, r.width() * 0.55, row_h), Qt.AlignLeft | Qt.AlignVCenter, STAT_LABELS[k])
            p.setPen(QColor(255, 255, 255, 235))
            p.drawText(QRectF(r.width() * 0.5, y, r.width() * 0.5 - pad, row_h), Qt.AlignRight | Qt.AlignVCenter, self._values.get(k, "—"))
            y += row_h
        if not self.cfg.click_through:           # resize grip
            p.setPen(QPen(QColor(255, 255, 255, 80), 1.5))
            for i in (4, 8, 12):
                p.drawLine(int(r.right() - i), int(r.bottom() - 2), int(r.right() - 2), int(r.bottom() - i))

    # -- drag / resize --------------------------------------------------------
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            pos = e.position().toPoint()
            self._resizing = pos.x() > self.width() - GRIP and pos.y() > self.height() - GRIP
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is None or not (e.buttons() & Qt.LeftButton):
            return
        if self._resizing:
            tl = self.frameGeometry().topLeft()
            g = e.globalPosition().toPoint() - tl
            self.resize(max(150, g.x()), max(80, g.y()))
        else:
            self.move(e.globalPosition().toPoint() - self._drag)
        self._save_timer.start()

    def mouseReleaseEvent(self, e):
        self._drag, self._resizing = None, False
        self._save_timer.start()

    def toggle(self) -> None:
        self.cfg.enabled = not self.isVisible()
        self.setVisible(self.cfg.enabled)
