from __future__ import annotations

import csv
import time
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox,
                               QFileDialog, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView,
                               QKeySequenceEdit, QLabel, QLineEdit, QListWidget, QMessageBox, QProgressBar,
                               QPushButton, QScrollArea, QSpinBox, QTableWidget, QTableWidgetItem,
                               QVBoxLayout, QWidget)
from PySide6.QtGui import QKeySequence

from .. import paths
from ..capture import grab_monitor, list_monitors
from ..stats import compute_history, compute_live, cumulative_series, fmt_duration
from . import theme
from .calibration import CalibrationDialog
from .overlay import STAT_LABELS
from .widgets import Card, CounterWidget, LineChart, StatusDot


def _title(text: str, sub: str = "") -> QWidget:
    w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0, 0, 0, 0); l.setSpacing(0)
    t = QLabel(text); t.setObjectName("title"); l.addWidget(t)
    if sub:
        s = QLabel(sub); s.setObjectName("muted"); l.addWidget(s)
    return w


def _table(headers: list[str]) -> QTableWidget:
    t = QTableWidget(0, len(headers)); t.setHorizontalHeaderLabels(headers)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers); t.setSelectionBehavior(QAbstractItemView.SelectRows)
    t.setAlternatingRowColors(True); t.verticalHeader().setVisible(False)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    return t


def _fmt_dt(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def _fill_sessions(table: QTableWidget, rows) -> None:
    table.setRowCount(len(rows))
    for i, s in enumerate(rows):
        dur = s.duration
        cpm = f"{s.total / (dur / 60):.2f}" if dur and dur >= 60 else "—"
        vals = [str(s.id), _fmt_dt(s.started_at), fmt_duration(dur) if dur is not None else "in progress",
                str(s.total), cpm, f"{s.start_source} / {s.end_reason or '…'}"]
        for j, v in enumerate(vals):
            it = QTableWidgetItem(v); it.setData(Qt.UserRole, s.id)
            if j in (0, 3, 4): it.setTextAlignment(Qt.AlignCenter)
            table.setItem(i, j, it)


# =============================================================================
class DashboardPage(QWidget):
    def __init__(self, ctl):
        super().__init__(); self.setObjectName("page"); self.ctl = ctl
        root = QVBoxLayout(self); root.setContentsMargins(24, 20, 24, 20); root.setSpacing(14)
        head = QHBoxLayout(); head.addWidget(_title("Dashboard", "Current game"), 1)
        self.b_session = QPushButton("Start session"); self.b_session.setObjectName("primary")
        self.b_add = QPushButton("+1"); self.b_rem = QPushButton("−1")
        for b in (self.b_rem, self.b_add, self.b_session): head.addWidget(b)
        root.addLayout(head)
        top = QHBoxLayout(); top.setSpacing(14)
        self.counter = CounterWidget(ctl.cfg.ui.accent); top.addWidget(self.counter, 2)
        grid = QGridLayout(); grid.setSpacing(10)
        self.c_cpm = Card("Chests / min"); self.c_time = Card("Elapsed"); self.c_avg = Card("Avg between chests")
        self.c_rare = Card("Rare / special"); 
        for i, c in enumerate((self.c_cpm, self.c_time, self.c_avg, self.c_rare)): grid.addWidget(c, i // 2, i % 2)
        top.addLayout(grid, 3); root.addLayout(top)
        card = QWidget(); cl = QVBoxLayout(card); cl.setContentsMargins(0, 0, 0, 0)
        cl.addWidget(QLabel("Progress this game")); self.chart = LineChart(ctl.cfg.ui.accent); cl.addWidget(self.chart)
        root.addWidget(card, 1)
        bottom = QHBoxLayout(); bottom.setSpacing(14)
        self.c_best = Card("Personal best"); self.c_mean = Card("Average / game"); self.c_games = Card("Games played")
        for c in (self.c_best, self.c_mean, self.c_games): bottom.addWidget(c)
        root.addLayout(bottom)
        root.addWidget(QLabel("Recent games"))
        self.recent = _table(["#", "Started", "Duration", "Chests", "Per min", "Start / end"]); self.recent.setMaximumHeight(170)
        root.addWidget(self.recent)
        self.b_add.clicked.connect(lambda: ctl.sessions.adjust(+1))
        self.b_rem.clicked.connect(lambda: ctl.sessions.adjust(-1))
        self.b_session.clicked.connect(ctl.toggle_session)
        ctl.session_event.connect(lambda *_: self.refresh())
        t = QTimer(self, interval=1000); t.timeout.connect(self.refresh); t.start()
        self._recent_n = -1
        self.refresh()

    def refresh(self) -> None:
        sm = self.ctl.sessions
        s = sm.stats()
        self.counter.set_value(s.total if sm.active else 0)
        self.b_session.setText("End session" if sm.active else "Start session")
        self.c_cpm.set(f"{s.per_minute:.2f}"); self.c_time.set(fmt_duration(s.elapsed) if sm.active else "—")
        self.c_avg.set(fmt_duration(s.avg_interval) if s.avg_interval else "—")
        self.c_rare.set(str(sum(n for k, n in s.kinds.items() if k != "normal")))
        self.chart.set_data(cumulative_series(sm.events(), sm.started_at, time.time()) if sm.active else [])
        rows = self.ctl.db.list_sessions()
        h = compute_history([r for r in rows])
        self.c_best.set(str(h.best)); self.c_mean.set(f"{h.average:.1f}"); self.c_games.set(str(h.sessions))
        key = (len(rows), sm.session_id)
        if key != self._recent_n:
            self._recent_n = key; _fill_sessions(self.recent, rows[:5])


# =============================================================================
class LivePage(QWidget):
    def __init__(self, ctl):
        super().__init__(); self.setObjectName("page"); self.ctl = ctl
        root = QVBoxLayout(self); root.setContentsMargins(24, 20, 24, 20); root.setSpacing(12)
        head = QHBoxLayout(); head.addWidget(_title("Live Tracker", "Real-time detection status"), 1)
        self.b_pause = QPushButton("Pause detection"); head.addWidget(self.b_pause); root.addLayout(head)
        self.warn = QLabel(); self.warn.setWordWrap(True); self.warn.setVisible(False)
        self.warn.setStyleSheet(f"background:{theme.PANEL_2}; border:1px solid {theme.WARN}; border-radius:8px; padding:10px; color:{theme.WARN}")
        root.addWidget(self.warn)
        g = QGridLayout(); g.setSpacing(10)
        self.d_game = StatusDot(); self.d_det = StatusDot(); self.d_calib = StatusDot(); self.d_key = StatusDot()
        for i, (lbl, w) in enumerate((("Fortnite", self.d_game), ("Detection", self.d_det),
                                      ("Calibration", self.d_calib), ("Interact key", self.d_key))):
            c = QGroupBox(lbl); l = QVBoxLayout(c); l.addWidget(w); g.addWidget(c, 0, i)
        root.addLayout(g)
        box = QGroupBox("Recognition"); f = QFormLayout(box)
        self.bar_prompt = QProgressBar(); self.bar_prompt.setRange(0, 100)
        self.bar_open = QProgressBar(); self.bar_open.setRange(0, 100)
        self.lbl_thr = QLabel(); self.lbl_conf = QLabel("—"); self.lbl_perf = QLabel("—"); self.lbl_sess = QLabel("—")
        f.addRow("'Open chest' prompt match", self.bar_prompt); f.addRow("'Opened' evidence", self.bar_open)
        f.addRow("Match threshold", self.lbl_thr); f.addRow("Last decision confidence", self.lbl_conf)
        f.addRow("Performance", self.lbl_perf); f.addRow("Session", self.lbl_sess)
        root.addWidget(box)
        root.addWidget(QLabel("Detection log (accepted AND rejected candidates)"))
        self.log = QListWidget(); root.addWidget(self.log, 1)
        self.b_pause.clicked.connect(ctl.toggle_pause)
        ctl.status_changed.connect(self.on_status)
        QTimer(self, interval=1000, timeout=self._session_label).start()

    def _session_label(self):
        sm = self.ctl.sessions
        self.lbl_sess.setText(f"#{sm.session_id} — {sm.total} chests — {fmt_duration(sm.stats().elapsed)}" if sm.active else "no active session")

    def on_status(self, st) -> None:
        cfg = self.ctl.cfg.detection
        self.b_pause.setText("Resume detection" if st.paused else "Pause detection")
        self.d_game.set("running" if st.game_running else "not detected", theme.OK if st.game_running else theme.MUTED)
        if st.paused: self.d_det.set("paused", theme.WARN)
        elif not st.ready: self.d_det.set("waiting for calibration", theme.WARN)
        elif not st.game_running: self.d_det.set("waiting for Fortnite", theme.MUTED)
        else: self.d_det.set(f"active — {st.fsm_state}", theme.OK)
        n = len(self.ctl.library.by_role("prompt")); o = len(self.ctl.library.by_role("opened"))
        self.d_calib.set(f"{n} prompt / {o} opened templates", theme.OK if n else theme.BAD)
        if cfg.use_interact_key and self.ctl.keys.available: self.d_key.set(f"'{cfg.interact_key}' monitored", theme.OK)
        elif cfg.use_interact_key: self.d_key.set("unavailable on this OS", theme.WARN)
        else: self.d_key.set("disabled (lower accuracy)", theme.WARN)
        self.bar_prompt.setValue(int(st.prompt_score * 100)); self.bar_open.setValue(int(st.opened_score * 100))
        self.lbl_thr.setText(f"{st.threshold:.2f}  (min. confidence to count: {cfg.min_confidence:.2f})")
        self.lbl_conf.setText("—" if st.last_confidence is None else
                              f"{st.last_confidence:.0%} → {st.last_decision}")
        self.lbl_perf.setText(f"{st.fps:.1f} analyses/s, {st.frame_ms:.1f} ms per frame" if st.fps else "idle")
        msg = st.error or st.warning
        self.warn.setVisible(bool(msg)); self.warn.setText(msg)
        if [self.log.item(i).text() for i in range(self.log.count())] != st.log[::-1]:
            self.log.clear(); self.log.addItems(st.log[::-1])


# =============================================================================
class HistoryPage(QWidget):
    def __init__(self, ctl):
        super().__init__(); self.setObjectName("page"); self.ctl = ctl
        root = QVBoxLayout(self); root.setContentsMargins(24, 20, 24, 20); root.setSpacing(12)
        head = QHBoxLayout(); head.addWidget(_title("History", "All recorded games"), 1)
        self.b_export = QPushButton("Export CSV"); self.b_del = QPushButton("Delete game")
        head.addWidget(self.b_export); head.addWidget(self.b_del); root.addLayout(head)
        self.table = _table(["#", "Started", "Duration", "Chests", "Per min", "Start / end"]); self.table.setMinimumHeight(160)
        root.addWidget(self.table, 1)
        det = QHBoxLayout(); det.setSpacing(14)
        left = QVBoxLayout(); self.c_total = Card("Chests"); self.c_cpm = Card("Per minute"); self.c_avg = Card("Avg interval"); self.c_kinds = Card("By kind")
        for c in (self.c_total, self.c_cpm, self.c_avg, self.c_kinds): left.addWidget(c)
        det.addLayout(left, 1)
        right = QVBoxLayout(); self.chart = LineChart(ctl.cfg.ui.accent); right.addWidget(self.chart, 1)
        self.events = _table(["Time", "Δ", "Kind", "Confidence", "Source"]); self.events.setMaximumHeight(150); right.addWidget(self.events)
        det.addLayout(right, 3); root.addLayout(det, 2)
        self.table.itemSelectionChanged.connect(self.show_selected)
        self.b_del.clicked.connect(self.delete_selected); self.b_export.clicked.connect(self.export)
        ctl.session_event.connect(lambda n, p: n.startswith("session") and self.refresh())
        self.refresh()

    def showEvent(self, e): self.refresh(); super().showEvent(e)

    def refresh(self) -> None:
        sel = self._selected_id()
        _fill_sessions(self.table, self.ctl.db.list_sessions())
        if sel:
            for r in range(self.table.rowCount()):
                if self.table.item(r, 0).data(Qt.UserRole) == sel: self.table.selectRow(r); break

    def _selected_id(self):
        it = self.table.selectedItems(); return it[0].data(Qt.UserRole) if it else None

    def show_selected(self) -> None:
        sid = self._selected_id()
        if not sid: return
        s = self.ctl.db.get_session(sid); ev = self.ctl.db.events(sid)
        if not s: return
        end = s.ended_at or time.time(); live = compute_live(ev, s.started_at, end)
        self.c_total.set(str(live.total)); self.c_cpm.set(f"{live.per_minute:.2f}")
        self.c_avg.set(fmt_duration(live.avg_interval) if live.avg_interval else "—")
        self.c_kinds.set(", ".join(f"{k}: {n}" for k, n in live.kinds.items()) or "—")
        self.chart.set_data(cumulative_series(ev, s.started_at, end))
        self.events.setRowCount(len(ev))
        for i, e in enumerate(ev):
            for j, v in enumerate((fmt_duration(e.offset_s), f"{e.delta:+d}", e.kind, f"{e.confidence:.0%}", e.source)):
                it = QTableWidgetItem(v); it.setTextAlignment(Qt.AlignCenter); self.events.setItem(i, j, it)

    def delete_selected(self) -> None:
        sid = self._selected_id()
        if not sid: return
        if sid == self.ctl.sessions.session_id:
            QMessageBox.information(self, "Delete", "End the current session first."); return
        if QMessageBox.question(self, "Delete game", f"Permanently delete game #{sid}?") == QMessageBox.Yes:
            self.ctl.db.delete_session(sid); self.refresh()

    def export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export", "chest_history.csv", "CSV (*.csv)")
        if not path: return
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["id", "started", "ended", "chests"])
            for sid, a, b, n in self.ctl.db.export_rows():
                w.writerow([sid, _fmt_dt(a), _fmt_dt(b) if b else "", n])


# =============================================================================
class SettingsPage(QWidget):
    def __init__(self, ctl, overlay, main_window):
        super().__init__(); self.setObjectName("page"); self.ctl, self.overlay, self.mw = ctl, overlay, main_window
        outer = QVBoxLayout(self); outer.setContentsMargins(24, 20, 24, 20)
        head = QHBoxLayout(); head.addWidget(_title("Settings"), 1)
        self.b_save = QPushButton("Save && apply"); self.b_save.setObjectName("primary"); head.addWidget(self.b_save)
        outer.addLayout(head)
        sc = QScrollArea(); sc.setWidgetResizable(True); outer.addWidget(sc, 1)
        body = QWidget(); body.setObjectName("page"); sc.setWidget(body)
        lay = QVBoxLayout(body); lay.setSpacing(12)
        d, o, h, u = ctl.cfg.detection, ctl.cfg.overlay, ctl.cfg.hotkeys, ctl.cfg.ui

        # --- detection
        g = QGroupBox("Detection"); f = QFormLayout(g)
        self.f_enabled = QCheckBox("Detection enabled"); self.f_enabled.setChecked(d.enabled)
        self.f_fps = QDoubleSpinBox(); self.f_fps.setRange(1, 30); self.f_fps.setValue(d.fps); self.f_fps.setSuffix(" analyses / s")
        self.f_mon = QComboBox()
        try:
            for i, name in enumerate(list_monitors(), 1): self.f_mon.addItem(name, i)
        except Exception:
            self.f_mon.addItem("Monitor 1", 1)
        self.f_mon.setCurrentIndex(max(0, self.f_mon.findData(d.monitor)))
        self.f_thr = QDoubleSpinBox(); self.f_thr.setRange(0.3, 0.99); self.f_thr.setSingleStep(0.01); self.f_thr.setValue(d.match_threshold)
        self.f_min = QDoubleSpinBox(); self.f_min.setRange(0.1, 1.0); self.f_min.setSingleStep(0.05); self.f_min.setValue(d.min_confidence)
        self.f_cool = QDoubleSpinBox(); self.f_cool.setRange(0, 30); self.f_cool.setValue(d.cooldown_s); self.f_cool.setSuffix(" s")
        self.f_key = QCheckBox("Use interact key as evidence (recommended)"); self.f_key.setChecked(d.use_interact_key)
        self.f_keyname = QLineEdit(d.interact_key); self.f_keyname.setMaximumWidth(80)
        self.f_auto = QCheckBox("Start / end games automatically"); self.f_auto.setChecked(d.auto_session)
        self.f_idle = QSpinBox(); self.f_idle.setRange(1, 120); self.f_idle.setValue(int(d.inactivity_end_s // 60)); self.f_idle.setSuffix(" min without activity")
        self.f_proc = QLineEdit(", ".join(d.process_names))
        self.f_only = QCheckBox("Only analyse while Fortnite is running (saves CPU)"); self.f_only.setChecked(d.only_when_game_running)
        for lbl, w in (("", self.f_enabled), ("Frequency", self.f_fps), ("Monitor", self.f_mon), ("Prompt match threshold", self.f_thr),
                       ("Min. confidence to count", self.f_min), ("Anti-duplicate cooldown", self.f_cool), ("", self.f_key),
                       ("Interact key", self.f_keyname), ("", self.f_auto), ("End game after", self.f_idle),
                       ("Game process names", self.f_proc), ("", self.f_only)):
            f.addRow(lbl, w)
        lay.addWidget(g)

        # --- calibration
        g = QGroupBox("Visual recognition calibration (required once)"); v = QVBoxLayout(g)
        info = QLabel("1) Launch Fortnite in <b>Windowed Fullscreen</b> and stand next to a closed chest so the interact prompt is visible.<br>"
                      "2) Click the button below, switch back to the game within 5 seconds: a screenshot is taken.<br>"
                      "3) Drag a rectangle around the prompt → save it as a <b>prompt</b> template. Optionally define the detection region.<br>"
                      "Templates are specific to your resolution/language/HUD scale; they are scaled automatically if you change resolution.")
        info.setWordWrap(True); info.setObjectName("muted"); v.addWidget(info)
        row = QHBoxLayout(); self.b_cal = QPushButton("Capture screenshot (5 s delay) & calibrate…"); self.b_cal.setObjectName("primary")
        self.b_open_tpl = QPushButton("Open templates folder"); row.addWidget(self.b_cal); row.addWidget(self.b_open_tpl); row.addStretch(); v.addLayout(row)
        self.roi_lbl = QLabel(); self.roi_lbl.setObjectName("muted"); v.addWidget(self.roi_lbl)
        self.tpl_list = QListWidget(); self.tpl_list.setMaximumHeight(110); v.addWidget(self.tpl_list)
        self.b_del_tpl = QPushButton("Delete selected template"); v.addWidget(self.b_del_tpl, 0, Qt.AlignLeft)
        lay.addWidget(g)

        # --- overlay
        g = QGroupBox("Overlay"); f = QFormLayout(g)
        self.o_en = QCheckBox("Show overlay"); self.o_en.setChecked(o.enabled)
        self.o_op = QDoubleSpinBox(); self.o_op.setRange(0.2, 1); self.o_op.setSingleStep(0.05); self.o_op.setValue(o.opacity)
        self.o_bg = QDoubleSpinBox(); self.o_bg.setRange(0, 1); self.o_bg.setSingleStep(0.05); self.o_bg.setValue(o.bg_alpha)
        self.o_fs = QDoubleSpinBox(); self.o_fs.setRange(0.5, 3); self.o_fs.setSingleStep(0.1); self.o_fs.setValue(o.font_scale)
        self.o_acc = QPushButton(o.accent); self.o_acc.clicked.connect(self._pick_overlay_color); self._ov_color = o.accent
        self.o_ct = QCheckBox("Click-through (lock; mouse passes through — unlock from the tray icon or here)"); self.o_ct.setChecked(o.click_through)
        self.o_hide = QCheckBox("Hide overlay when Fortnite is not running"); self.o_hide.setChecked(o.hide_when_game_closed)
        self.o_stats = {}
        sbox = QWidget(); sl = QHBoxLayout(sbox); sl.setContentsMargins(0, 0, 0, 0)
        for k, lbl in STAT_LABELS.items():
            cb = QCheckBox(lbl); cb.setChecked(k in o.stats); self.o_stats[k] = cb; sl.addWidget(cb)
        self.b_reset_ov = QPushButton("Reset overlay position")
        for lbl, w in (("", self.o_en), ("Window opacity", self.o_op), ("Background opacity", self.o_bg), ("Size / text scale", self.o_fs),
                       ("Accent color", self.o_acc), ("", self.o_ct), ("", self.o_hide), ("Statistics (first = large)", sbox), ("", self.b_reset_ov)):
            f.addRow(lbl, w)
        n = QLabel("Drag the overlay to move it; drag its bottom-right corner to resize. Works on any monitor. "
                   "It is visible over Fortnite in <b>Windowed Fullscreen</b>; Windows cannot draw regular windows over exclusive fullscreen.")
        n.setWordWrap(True); n.setObjectName("muted"); f.addRow(n)
        lay.addWidget(g)

        # --- hotkeys
        g = QGroupBox("Global hotkeys"); f = QFormLayout(g)
        self.hk = {}
        for key, lbl in (("toggle_overlay", "Show / hide overlay"), ("toggle_detection", "Pause / resume detection"),
                         ("add_chest", "+1 chest (manual correction)"), ("remove_chest", "−1 chest (manual correction)"),
                         ("toggle_session", "Start / end game")):
            e = QKeySequenceEdit(QKeySequence(getattr(h, key))); self.hk[key] = e; f.addRow(lbl, e)
        lay.addWidget(g)

        # --- display + paths
        g = QGroupBox("Display"); f = QFormLayout(g)
        self.u_acc = QPushButton(u.accent); self.u_acc.clicked.connect(self._pick_ui_color); self._ui_color = u.accent
        f.addRow("App accent color", self.u_acc); lay.addWidget(g)
        g = QGroupBox("Data & files"); f = QFormLayout(g)
        for lbl, p in (("Data folder", paths.data_dir()), ("Database", paths.db_path()), ("Logs", paths.log_dir())):
            l = QLabel(str(p)); l.setTextInteractionFlags(Qt.TextSelectableByMouse); f.addRow(lbl, l)
        self.dbg = QCheckBox("Verbose logging (applies on next start)"); self.dbg.setChecked(ctl.cfg.debug); f.addRow("", self.dbg)
        row = QHBoxLayout(); b1 = QPushButton("Open data folder"); b2 = QPushButton("Open logs folder")
        b1.clicked.connect(lambda: ctl.open_folder(paths.data_dir())); b2.clicked.connect(lambda: ctl.open_folder(paths.log_dir()))
        row.addWidget(b1); row.addWidget(b2); row.addStretch(); w = QWidget(); w.setLayout(row); f.addRow(w)
        portable = QLabel("Portable mode: create an empty file named <b>portable.txt</b> next to the .exe to keep all data in a <b>data</b> folder beside it.")
        portable.setObjectName("muted"); portable.setWordWrap(True); f.addRow(portable)
        lay.addWidget(g); lay.addStretch()

        self.b_save.clicked.connect(self.save); self.b_cal.clicked.connect(self.start_calibration)
        self.b_open_tpl.clicked.connect(lambda: ctl.open_folder(paths.templates_dir()))
        self.b_del_tpl.clicked.connect(self.delete_template); self.b_reset_ov.clicked.connect(overlay.reset_position)
        self._refresh_templates()

    # -- helpers
    def _pick_overlay_color(self):
        c = QColorDialog.getColor(parent=self)
        if c.isValid(): self._ov_color = c.name(); self.o_acc.setText(self._ov_color)

    def _pick_ui_color(self):
        c = QColorDialog.getColor(parent=self)
        if c.isValid(): self._ui_color = c.name(); self.u_acc.setText(self._ui_color)

    def _refresh_templates(self):
        self.tpl_list.clear()
        for t in self.ctl.library.items:
            self.tpl_list.addItem(f"{t.role:7s} | {t.kind:10s} | ref {t.ref_height}p | {t.path.name}")
        r = self.ctl.cfg.detection.roi
        self.roi_lbl.setText(f"Detection region (fractions of screen): x={r[0]:.2f} y={r[1]:.2f} w={r[2]:.2f} h={r[3]:.2f}")

    def delete_template(self):
        i = self.tpl_list.currentRow()
        if i >= 0:
            self.ctl.library.remove(self.ctl.library.items[i]); self.ctl.engine.reconfigure(); self._refresh_templates()

    def start_calibration(self):
        self.mw.hide(); self.overlay.hide(); self.b_cal.setEnabled(False)
        QTimer.singleShot(5000, self._do_capture)

    def _do_capture(self):
        try:
            bgr, _ = grab_monitor(self.ctl.cfg.detection.monitor)
        except Exception as exc:
            self.mw.show(); self.b_cal.setEnabled(True)
            QMessageBox.warning(self, "Capture failed", str(exc)); return
        if self.ctl.cfg.overlay.enabled: self.overlay.show()
        self.mw.show(); self.mw.raise_(); self.b_cal.setEnabled(True)
        CalibrationDialog(bgr, self.ctl, self).exec()
        self._refresh_templates()

    def save(self):
        c = self.ctl.cfg; d, o, h = c.detection, c.overlay, c.hotkeys
        d.enabled = self.f_enabled.isChecked(); d.fps = self.f_fps.value(); d.monitor = self.f_mon.currentData() or 1
        d.match_threshold = self.f_thr.value(); d.min_confidence = self.f_min.value(); d.cooldown_s = self.f_cool.value()
        d.use_interact_key = self.f_key.isChecked(); d.interact_key = self.f_keyname.text().strip().upper() or "E"
        d.auto_session = self.f_auto.isChecked(); d.inactivity_end_s = self.f_idle.value() * 60.0
        d.process_names = [x.strip() for x in self.f_proc.text().split(",") if x.strip()] or d.process_names
        d.only_when_game_running = self.f_only.isChecked()
        o.enabled = self.o_en.isChecked(); o.opacity = self.o_op.value(); o.bg_alpha = self.o_bg.value(); o.font_scale = self.o_fs.value()
        o.accent = self._ov_color; o.click_through = self.o_ct.isChecked(); o.hide_when_game_closed = self.o_hide.isChecked()
        o.stats = [k for k, cb in self.o_stats.items() if cb.isChecked()] or ["chests"]
        for k, e in self.hk.items():
            setattr(h, k, e.keySequence().toString(QKeySequence.PortableText) or getattr(h, k))
        c.ui.accent = self._ui_color; c.debug = self.dbg.isChecked()
        self.ctl.save_and_apply(); self.overlay.apply_config(); self.overlay.setVisible(o.enabled)
        self.mw.apply_theme(); self._refresh_templates()
        self.ctl.toast.emit("Settings saved")
