"""Dark gaming theme (black / anthracite + violet accent)."""
BG = "#0d0e12"
PANEL = "#16181f"
PANEL_2 = "#1d2029"
BORDER = "#2a2e3a"
TEXT = "#e8eaf0"
MUTED = "#8b91a3"
OK = "#34d399"
WARN = "#fbbf24"
BAD = "#f87171"


def stylesheet(accent: str = "#8b5cf6") -> str:
    return f"""
* {{ font-family: 'Segoe UI Variable', 'Segoe UI', 'Inter', 'Noto Sans', sans-serif; font-size: 13px; color: {TEXT}; }}
QMainWindow, QDialog, QWidget#root {{ background: {BG}; }}
QWidget#page {{ background: {BG}; }}
QFrame#card {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 12px; }}
QFrame#sidebar {{ background: {PANEL}; border-right: 1px solid {BORDER}; }}
QLabel#title {{ font-size: 22px; font-weight: 700; }}
QLabel#muted {{ color: {MUTED}; }}
QLabel#cardTitle {{ color: {MUTED}; font-size: 11px; font-weight: 600; letter-spacing: 1px; }}
QLabel#cardValue {{ font-size: 24px; font-weight: 700; }}
QLabel#brand {{ font-size: 15px; font-weight: 800; color: {accent}; letter-spacing: 1px; }}
QPushButton {{ background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 8px 14px; }}
QPushButton:hover {{ border-color: {accent}; }}
QPushButton:pressed {{ background: {BORDER}; }}
QPushButton:disabled {{ color: {MUTED}; }}
QPushButton#primary {{ background: {accent}; border: none; font-weight: 600; color: white; }}
QPushButton#primary:hover {{ background: {accent}; }}
QPushButton#nav {{ text-align: left; background: transparent; border: none; padding: 10px 16px; border-radius: 8px; color: {MUTED}; font-size: 14px; }}
QPushButton#nav:hover {{ background: {PANEL_2}; color: {TEXT}; }}
QPushButton#nav:checked {{ background: {PANEL_2}; color: {TEXT}; border-left: 3px solid {accent}; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QKeySequenceEdit {{ background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 6px; padding: 5px 8px; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{ border-color: {accent}; }}
QComboBox QAbstractItemView {{ background: {PANEL_2}; selection-background-color: {accent}; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {BORDER}; background: {PANEL_2}; }}
QCheckBox::indicator:checked {{ background: {accent}; border-color: {accent}; }}
QTableWidget, QListWidget {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 10px; gridline-color: {BORDER}; alternate-background-color: {PANEL_2}; selection-background-color: {accent}; }}
QHeaderView::section {{ background: {PANEL_2}; color: {MUTED}; border: none; padding: 6px; font-weight: 600; }}
QGroupBox {{ border: 1px solid {BORDER}; border-radius: 10px; margin-top: 14px; padding: 14px 10px 10px 10px; background: {PANEL}; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 6px; color: {MUTED}; font-weight: 600; }}
QProgressBar {{ background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 6px; text-align: center; height: 14px; }}
QProgressBar::chunk {{ background: {accent}; border-radius: 5px; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; }}
QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 5px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QToolTip {{ background: {PANEL_2}; border: 1px solid {BORDER}; color: {TEXT}; }}
"""
