from __future__ import annotations

import logging
import sys

from . import APP_NAME, __version__, paths
from .logging_setup import setup_logging

log = logging.getLogger(__name__)


def selftest() -> int:
    """Headless smoke test used by CI on the built .exe: exercises DB, config, OpenCV
    template matching, the state machine and imports Qt — then writes selftest.txt."""
    import os, tempfile
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    tmp = tempfile.mkdtemp(prefix="flcc-selftest-")
    os.environ["FLCC_DATA_DIR"] = tmp
    out = []
    try:
        import cv2, numpy as np
        from PySide6.QtWidgets import QApplication
        from .config import AppConfig
        from .db import Database
        from .detection.base import Observation
        from .detection.state_machine import ChestStateMachine
        from .detection.templates import TemplateLibrary, TemplateRecogniser
        from .session import SessionManager
        from .ui.main_window import MainWindow  # noqa: F401  (import check of the whole UI)
        import mss, psutil  # noqa: F401
        app = QApplication.instance() or QApplication([])
        cfg = AppConfig()
        db = Database(paths.db_path())
        sm = SessionManager(db, cfg.detection)
        assert sm.add_detection("normal", 0.9).counted and sm.total == 1
        assert not sm.add_detection("normal", 0.9).counted   # dedupe
        img = np.full((60, 160, 3), 40, np.uint8); cv2.putText(img, "OPEN", (8, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (240,) * 3, 3)
        lib = TemplateLibrary(paths.templates_dir()); lib.add("prompt", "normal", img, 1080)
        scene = np.random.default_rng(1).integers(20, 70, (300, 500, 3), dtype=np.uint8); scene[100:160, 200:360] = img
        assert TemplateRecogniser(lib, [1.0]).observe(scene, 1080, 0).prompt_score > 0.9
        fsm = ChestStateMachine(cfg.detection); fsm.update(Observation(0, 0.9))
        out.append(f"OK version={__version__} cv2={cv2.__version__} data={paths.data_dir()}")
        code = 0
    except Exception as exc:  # pragma: no cover
        import traceback
        out.append("FAIL " + "".join(traceback.format_exception(exc)))
        code = 1
    text = "\n".join(out)
    print(text)
    for target in (paths.app_root() / "selftest.txt", __import__("pathlib").Path(tempfile.gettempdir()) / "flcc-selftest.txt"):
        try:
            target.write_text(text, encoding="utf-8")
        except OSError:
            pass
    return code


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--version" in argv:
        print(__version__); return 0
    if "--selftest" in argv:
        return selftest()
    from PySide6.QtWidgets import QApplication, QMessageBox
    cfg_debug = "--debug" in argv
    setup_logging(cfg_debug)
    log.info("%s %s starting (data: %s)", APP_NAME, __version__, paths.data_dir())
    app = QApplication(sys.argv[:1])
    app.setApplicationName(APP_NAME); app.setQuitOnLastWindowClosed(False)
    try:
        from .controller import Controller
        from .ui.main_window import MainWindow
        ctl = Controller()
        win = MainWindow(ctl)
        win.show()
    except Exception as exc:
        log.exception("fatal startup error")
        QMessageBox.critical(None, APP_NAME, f"Startup failed:\n{exc}\n\nSee logs in {paths.log_dir()}")
        return 1
    return app.exec()
