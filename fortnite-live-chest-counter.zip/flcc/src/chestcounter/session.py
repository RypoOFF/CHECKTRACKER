"""Session lifecycle + the single place where the counter changes.

All counter mutations (vision, manual, future replay verification) go through
:class:`SessionManager`, which enforces dedupe, confidence gating and persistence.
Pure Python (no Qt) so it is fully testable; UIs subscribe via ``subscribe``.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable

from .config import DetectionConfig
from .db import Database, EventRow
from .stats import LiveStats, compute_live

log = logging.getLogger("chestcounter.detection.session")

Listener = Callable[[str, dict], None]


@dataclass
class AddResult:
    counted: bool
    reason: str  # 'counted' | 'duplicate' | 'low_confidence' | 'no_session' | 'paused'


class SessionManager:
    def __init__(self, db: Database, cfg: DetectionConfig, clock: Callable[[], float] = time.time):
        self.db, self.cfg, self.clock = db, cfg, clock
        self._lock = threading.RLock()
        self._listeners: list[Listener] = []
        self.session_id: int | None = None
        self.started_at: float = 0.0
        self._events: list[EventRow] = []
        self._last_counted_ts: float = -1e9
        self._last_activity: float = 0.0
        self.last_rejected: str = ""
        self._game_seen = False

    # -- observers ----------------------------------------------------------
    def subscribe(self, fn: Listener) -> None:
        self._listeners.append(fn)

    def _emit(self, name: str, **payload) -> None:
        for fn in list(self._listeners):
            try:
                fn(name, payload)
            except Exception:  # a broken UI listener must never break counting
                log.exception("listener failed for %s", name)

    # -- state --------------------------------------------------------------
    @property
    def active(self) -> bool:
        return self.session_id is not None

    @property
    def total(self) -> int:
        with self._lock:
            return sum(e.delta for e in self._events)

    def events(self) -> list[EventRow]:
        with self._lock:
            return list(self._events)

    def stats(self, now: float | None = None) -> LiveStats:
        with self._lock:
            if not self.active:
                return LiveStats()
            return compute_live(self._events, self.started_at, now or self.clock())

    # -- lifecycle ----------------------------------------------------------
    def start(self, source: str = "manual", ts: float | None = None) -> int:
        with self._lock:
            if self.active:
                self.end("restarted")
            ts = ts or self.clock()
            self.session_id = self.db.create_session(ts, source)
            self.started_at = ts
            self._events = []
            self._last_counted_ts = -1e9
            self._last_activity = ts
            self._game_seen = False
            log.info("session %s started (%s)", self.session_id, source)
        self._emit("session_started", session_id=self.session_id)
        return self.session_id

    def end(self, reason: str = "manual") -> int | None:
        with self._lock:
            if not self.active:
                return None
            sid = self.session_id
            now = self.clock()
            total = self.total
            if total == 0 and now - self.started_at < 60:
                self.db.delete_session(sid)  # nothing worth keeping
                log.info("session %s discarded (empty, %s)", sid, reason)
                kept = False
            else:
                self.db.end_session(sid, now, reason)
                kept = True
                log.info("session %s ended (%s) total=%d", sid, reason, total)
            self.session_id = None
            self._events = []
        self._emit("session_ended", session_id=sid, reason=reason, kept=kept)
        return sid

    # -- counter mutations --------------------------------------------------
    def add_detection(self, kind: str, confidence: float, ts: float | None = None,
                      source: str = "vision", details: str = "") -> AddResult:
        ts = ts or self.clock()
        with self._lock:
            if confidence < self.cfg.min_confidence:
                self.last_rejected = f"low confidence {confidence:.2f}"
                log.info("REJECT low_confidence kind=%s conf=%.2f %s", kind, confidence, details)
                self._emit("rejected", reason="low_confidence", confidence=confidence, kind=kind)
                return AddResult(False, "low_confidence")
            if ts - self._last_counted_ts < self.cfg.cooldown_s:
                self.last_rejected = "duplicate (cooldown)"
                log.info("REJECT duplicate kind=%s conf=%.2f dt=%.2fs", kind, confidence,
                         ts - self._last_counted_ts)
                self._emit("rejected", reason="duplicate", confidence=confidence, kind=kind)
                return AddResult(False, "duplicate")
            if not self.active:
                if not self.cfg.auto_session:
                    return AddResult(False, "no_session")
                self.start("auto", ts=ts)
            self._record(+1, kind, confidence, source, ts, details)
            self._last_counted_ts = ts
            log.info("COUNT kind=%s conf=%.2f source=%s total=%d %s", kind, confidence, source,
                     self.total, details)
        self._emit("counted", total=self.total, kind=kind, confidence=confidence, source=source)
        return AddResult(True, "counted")

    def adjust(self, delta: int, kind: str = "normal") -> bool:
        """Manual correction (+1 / -1). Never drops the total below zero."""
        with self._lock:
            if delta < 0 and self.total + delta < 0:
                return False
            if not self.active:
                if delta < 0:
                    return False
                self.start("manual")
            ts = self.clock()
            if delta < 0:
                # prefer removing the most recent matching kind to keep per-kind stats coherent
                kinds = [e.kind for e in self._events if e.delta > 0]
                kind = next((k for k in reversed(kinds) if k == kind), kinds[-1] if kinds else kind)
            self._record(delta, kind, 1.0, "manual", ts, "manual correction")
            self._last_activity = ts
        self._emit("counted", total=self.total, kind=kind, confidence=1.0, source="manual")
        return True

    def _record(self, delta, kind, conf, source, ts, details) -> None:
        eid = self.db.add_event(self.session_id, ts, ts - self.started_at, delta, kind, conf, source, details)
        self._events.append(EventRow(eid, self.session_id, ts, ts - self.started_at, delta, kind,
                                     conf, source, details))
        self._last_activity = ts

    # -- periodic housekeeping ---------------------------------------------
    def tick(self, game_running: bool, now: float | None = None) -> None:
        now = now or self.clock()
        with self._lock:
            if not self.active:
                return
            if game_running:
                self._game_seen = True
            if self.cfg.end_on_game_close and self._game_seen and not game_running:
                reason = "game_closed"
            elif now - self._last_activity > self.cfg.inactivity_end_s:
                reason = "inactivity"
            else:
                return
        self.end(reason)
