"""Fortnite Live Chest Counter."""
__version__ = "1.0.0"
APP_NAME = "Fortnite Live Chest Counter"
