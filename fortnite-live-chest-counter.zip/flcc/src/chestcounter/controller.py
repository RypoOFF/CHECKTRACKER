"""Glue between the pure-Python core and the Qt UI."""
from __future__ import annotations

import logging
import subprocess
import sys

from PySide6.QtCore import QObject, Signal

from . import paths
from .capture import MssSource
from .config import AppConfig
from .db import Database
from .detection.engine import DetectionEngine, EngineStatus
from .detection.keystate import KeyWatcher
from .detection.templates import TemplateLibrary, TemplateRecogniser
from .hotkeys import HotkeyManager
from .session import SessionManager

log = logging.getLogger(__name__)


class Controller(QObject):
    status_changed = Signal(object)          # EngineStatus (from worker thread)
    session_event = Signal(str, dict)        # name, payload (counted / rejected / session_*)
    toast = Signal(str)
    hotkey_overlay = Signal()
    hotkey_detection = Signal()
    hotkey_add = Signal()
    hotkey_remove = Signal()
    hotkey_session = Signal()
    config_applied = Signal()

    def __init__(self, cfg: AppConfig | None = None, db: Database | None = None, start_engine: bool = True):
        super().__init__()
        self.cfg = cfg or AppConfig.load(paths.config_path())
        self.db = db or Database(paths.db_path())
        recovered = self.db.close_dangling_sessions(__import__("time").time())
        if recovered:
            log.warning("Recovered %d unfinished session(s) after unclean shutdown", recovered)
        self.sessions = SessionManager(self.db, self.cfg.detection)
        self.sessions.subscribe(lambda n, p: self.session_event.emit(n, p))
        self.library = TemplateLibrary(paths.templates_dir())
        self.recogniser = TemplateRecogniser(self.library, self.cfg.detection.scales)
        self.keys = KeyWatcher(self.cfg.detection.interact_key)
        self.hotkeys = HotkeyManager()
        self.engine = DetectionEngine(
            self.cfg.detection, self.recogniser, self.sessions, self.keys,
            source_factory=lambda: MssSource(self.cfg.detection.monitor, self.cfg.detection.roi),
            on_status=lambda s: self.status_changed.emit(s))
        self.last_status = EngineStatus()
        self.status_changed.connect(lambda s: setattr(self, "last_status", s))
        if start_engine:
            self.keys.start()
            self.engine.start()
            self.apply_hotkeys()

    # -- settings -----------------------------------------------------------
    def save_and_apply(self) -> None:
        self.recogniser.scales = self.cfg.detection.scales or [1.0]
        try:
            self.cfg.save(paths.config_path())
        except OSError as exc:
            self.toast.emit(f"Could not save settings: {exc}")
        self.engine.reconfigure()
        self.apply_hotkeys()
        self.config_applied.emit()

    def apply_hotkeys(self) -> None:
        h = self.cfg.hotkeys
        failed = self.hotkeys.register({
            "toggle_overlay": (h.toggle_overlay, self.hotkey_overlay.emit),
            "toggle_detection": (h.toggle_detection, self.hotkey_detection.emit),
            "add_chest": (h.add_chest, self.hotkey_add.emit),
            "remove_chest": (h.remove_chest, self.hotkey_remove.emit),
            "toggle_session": (h.toggle_session, self.hotkey_session.emit),
        })
        if failed:
            self.toast.emit("Hotkey problem: " + "; ".join(failed))

    # -- actions ------------------------------------------------------------
    def toggle_pause(self) -> bool:
        paused = self.engine.toggle_pause()
        self.save_and_apply()
        self.toast.emit("Detection paused" if paused else "Detection resumed")
        return paused

    def toggle_session(self) -> None:
        if self.sessions.active:
            self.sessions.end("manual")
        else:
            self.sessions.start("manual")

    def open_folder(self, path) -> None:
        try:
            if sys.platform == "win32":
                import os
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            self.toast.emit(f"Cannot open folder: {exc}")

    def shutdown(self) -> None:
        self.hotkeys.stop()
        self.engine.stop()
        self.keys.stop()
        if self.engine.is_alive():
            self.engine.join(2)
        self.sessions.end("app_closed")
        try:
            self.cfg.save(paths.config_path())
        except OSError:
            pass
        self.db.close()
