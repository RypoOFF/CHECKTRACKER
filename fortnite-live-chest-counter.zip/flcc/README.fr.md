# Fortnite Live Chest Counter

**Compteur de coffres Fortnite en temps réel, avec overlay transparent et tableau de bord statistique.**
Inspiré de [LED-N/Fortnite-ChestCounter](https://github.com/LED-N/Fortnite-ChestCounter), qui lit les fichiers replay *après* la partie. Ici, le comptage se fait **pendant que vous jouez**.

🇬🇧 [Read in English](README.md)

![Dashboard](docs/screenshots/dashboard.png)

> Les captures utilisent des **données de démonstration synthétiques**, pas de vraies parties.

## Téléchargement

1. Ouvrez la page **[Releases](../../releases)**.
2. Téléchargez `FortniteLiveChestCounter-vX.Y.Z-windows-x64.exe` dans **Assets**.
3. Lancez-le : rien à installer (ni Python, ni Visual Studio). Windows SmartScreen peut afficher « Windows a protégé votre ordinateur » (exe non signé) : *Informations complémentaires → Exécuter quand même*. Un fichier `.sha256` permet de vérifier le téléchargement.

Mode portable : créez un fichier vide `portable.txt` à côté de l'exe ; les données seront dans un dossier `data` voisin. Sinon : `%APPDATA%\FortniteLiveChestCounter`.

## Première configuration (≈ 2 min, obligatoire)

> **Transparence :** l'application ne contient **aucun modèle de reconnaissance préentraîné**. Le message « ouvrir le coffre » dépend de votre résolution, de votre langue et de l'échelle de l'interface, et je n'ai pas pu valider de modèles fournis sur de vraies images de Fortnite. Vous calibrez une fois, sur votre propre écran.

1. Passez Fortnite en **Plein écran fenêtré** (nécessaire pour la capture et pour voir l'overlay).
2. Placez-vous près d'un coffre fermé pour que le message d'interaction soit visible.
3. Dans l'app : **Paramètres → Calibration → Capturer**, puis revenez au jeu en moins de 5 s.
4. Tracez un rectangle serré autour du message → mode *Template: prompt* → **Save selection**. Ajoutez plusieurs exemples (pour d'autres types de coffres, mettez `rare`, `special`… dans *Kind*).
5. Optionnel : définissez la *région de détection* (plus petite = moins de CPU).
6. Jouez, et surveillez l'onglet **Live Tracker**.

## Fonctionnement

L'app ne compte pas « un coffre fermé est visible » (il serait compté sans arrêt) mais une **transition** : le message apparaît → il disparaît → un score de confiance est calculé à partir de : correspondance du message, **touche d'interaction pressée juste avant la disparition** (lue via `GetAsyncKeyState`, sans hook) et, en option, un modèle « coffre ouvert ». Sous le seuil de confiance, le candidat est **journalisé mais pas compté**. La déduplication combine ré-armement de la machine à états et délai global anti-doublon. Détails : [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

**Conformité :** capture d'écran et lecture de l'état d'une touche uniquement. Aucun accès à la mémoire, aucune injection, aucune DLL, aucune simulation d'entrées. Je ne peux pas garantir la position d'Epic ni la façon dont un anti-triche classe un overlay tiers : usage à vos risques.

## Fonctionnalités

Compteur en direct, coffres/minute (global et 5 dernières minutes), temps moyen entre coffres, chronomètre ; coffres rares/spéciaux **uniquement si vous créez des modèles de ces types** ; début/fin de partie automatiques et réinitialisation entre parties ; correction manuelle (+1/−1, boutons et raccourcis) ; overlay transparent, au premier plan, déplaçable, redimensionnable, personnalisable, multi-écrans, avec raccourci ; Dashboard, Live Tracker, Historique, Paramètres ; stockage SQLite local ; logs de détection ; fréquence d'analyse réglable ; pause.

Raccourcis par défaut : `Ctrl+Alt+O` overlay · `Ctrl+Alt+P` pause · `Ctrl+Alt+↑/↓` +1/−1 · `Ctrl+Alt+S` début/fin de partie.

## Limites

- **Pas fiable à 100 %** : calibrez soigneusement, surveillez le Live Tracker, corrigez manuellement si besoin.
- Pas de modèles fournis ; un changement de résolution/langue/interface peut nécessiter une recalibration.
- **Coffres par joueur : indisponible** par analyse d'écran.
- Début/fin de partie non lisibles à l'écran : la partie démarre au premier coffre détecté et se termine après inactivité (10 min par défaut), à la fermeture de Fortnite ou manuellement.
- Le plein écran exclusif peut donner des captures noires et masque l'overlay.
- La vérification par fichiers replay n'est **pas encore implémentée**.
- Non testé par l'auteur sur une vraie session Fortnite.

## Développement et publication

Voir [README.md](README.md#development). Pour publier : modifiez `__version__` et `CHANGELOG.md`, puis `git tag vX.Y.Z && git push origin vX.Y.Z` — GitHub Actions compile l'exe sous Windows et l'ajoute aux Assets de la Release.

## Licence

MIT — voir [LICENSE](LICENSE). Non affilié à Epic Games.
