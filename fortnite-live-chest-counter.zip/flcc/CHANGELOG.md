# Changelog

Each `## [x.y.z]` section is used verbatim as the GitHub Release description.

## [1.0.0] - 2026-11-18

### New
- Real-time chest counter: screen analysis (OpenCV template matching) while Fortnite is running — no replay needed.
- Hybrid evidence model: interact-prompt disappearance + interact-key state (+ optional "opened" template) → confidence score.
- Per-detection confidence, rejected candidates logged and shown in the Live Tracker.
- Reliable de-duplication (state machine re-arming + global cooldown).
- Transparent, always-on-top, draggable/resizable overlay with configurable statistics; multi-monitor aware; click-through mode.
- Dashboard, Live Tracker, History, Settings; step chart; personal best / average / chests per minute / average interval.
- Automatic game start (first detected chest) and end (inactivity or Fortnite closing); manual start/end.
- Manual correction (+1 / −1) via buttons and global hotkeys; every change is stored as an auditable event.
- Local SQLite storage; CSV export; portable mode (`portable.txt`).
- Built-in calibration tool to capture templates from your own screen.

### Known limitations
- **No templates are bundled**: you must calibrate once (≈2 minutes) — see README.
- Per-player chest counts and rare/special classification depend on your templates; per-player stats are not available.
- Exclusive fullscreen can produce black captures and hides the overlay: use *Windowed Fullscreen*.
- Replay-file verification is not implemented yet (planned).
- The .exe is unsigned: Windows SmartScreen may warn ("More info → Run anyway").
